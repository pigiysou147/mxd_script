﻿/**
 * Event : 跑旗赛
 * @author Yukinoshita
 */
portal.abortWarp();
let event = portal.getEvent("event_pqs");
if (event != null) {
    if (event.getVariable("started")) {
        if (player.getEvent() == null) {
            player.setEvent(event);
            event.getVariable("members").push(player);
            player.dropMessage(9, "发生了一个错误。虽然已被规避，但是请告知管理者。");
        }
        let ranking = event.getVariable("ranking");
        //let currentRank = event.getVariable("currentRank");//当前是第几名
        if (ranking[player.getName()] == null) {
            ranking[player.getName()] = { LAP: 0, BESTLAP: 2147483647, LAPTIME: 0, PASTTIME: 0 ,RANK : 99};//初始化玩家的排名信息
        }
        //event.setVariable("currentRank", currentRank);
        //if (currentRank == (members.length - 1)) {//如果全部玩家都通过了检查点，重置当前排行
        //    event.setVariable("currentRank", 0);
        //}
        switch (map.getId()) {
            case 932200100:
            case 932200300:
                player.teleportToPortalId(0, 16);
                break;
            case 932200200:
                player.teleportToPortalId(0, 1);
                break;
        }
    } else {
        portal.abortWarp();
        player.dropMessage(-1, "不要着急，还没开始呢。");
    }
} else {
    player.dropMessage(-1, "不是活动时间。但是你仍然可以进行练习。");
    switch (map.getId()) {
        case 932200100:
        case 932200300:
            player.teleportToPortalId(0, 16);
            break;
        case 932200200:
            player.teleportToPortalId(0, 1);
            break;
    }
}
