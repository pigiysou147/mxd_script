﻿/**
 * Event : 跑旗赛
 * @author Yukinoshita
 */


let mapId = map.getId();

let event = portal.getEvent("event_pqs");
if(event != null){
    portal.getEvent("event_manager").setVariable("pqsRanking", event.getVariable("ranking"));
    let maxLap = event.getVariable("maxLap");
    let ranking = event.getVariable("ranking");
    
    let startTime = event.getVariable("startTime");
    let bestLapTime = event.getVariable("bestLapTime");
    let pastTime = new Date().getTime() - startTime;
    let members = event.getVariable("members");
    //let lapTime = pastTime;
    let lap = 0;
    let rank = members.length - 1;
    newLapTime = 0;
    if (ranking[player.getName()] == null) {
        ranking[player.getName()] = { LAP: 1, BESTLAP: 2147483647, LAPTIME: 0 ,PASTTIME: pastTime, RANK : -1};//初始化玩家的排名信息
        player.dropMessage(9, "发生了一个错误。虽然已被规避，但是请告知管理者。");
    } else {
        lap = ranking[player.getName()]["LAP"];
        ranking[player.getName()]["LAP"] = ++lap;
        ranking[player.getName()]["PASTTIME"] = pastTime;
        let lastLapTime = ranking[player.getName()]["LAPTIME"];
        let playerBestLapTime = ranking[player.getName()]["BESTLAP"];
        newLapTime = pastTime - lastLapTime;
        ranking[player.getName()]["LAPTIME"] = pastTime;
        if(newLapTime < playerBestLapTime){
            ranking[player.getName()]["BESTLAP"] = newLapTime;
        }
        if(newLapTime < bestLapTime["time"]){
            player.dropMessage(0, "全场最佳单圈！" + formatDuring(newLapTime) + "。上一位全场最佳是" + bestLapTime["player"] + "的" + formatDuring(bestLapTime["time"]) + "。");
            //broadcastEventNotice(5, "" + player.getName() + "刷新了" + bestLapTime["player"] + "的全场最佳单圈时间" + bestLapTime["time"] + "秒。目前排名第" + rank + "。");
            bestLapTime["time"] = newLapTime;
            bestLapTime["player"] = player.getName();
            
        }
    }
    for(let i = 0; i < members.length; i++){
        if(ranking[members[i].getName()] == null){
            ranking[members[i].getName()] = { LAP: 0, BESTLAP: 2147483647, LAPTIME: 0 ,PASTTIME: pastTime, RANK : 99};//你为什么不跑！
        }
        if (ranking[members[i].getName()] != null) {
            let memberName = members[i].getName();
            if(ranking[memberName]["LAP"] < lap)
            rank --;
        }
    }
    event.getVariable("range")[player.getId()] = 0;
    event.getVariable("score")[player.getId()] += 50;
    let clear = false;
    let toPortal = 0;
    if(lap >= maxLap){
        clear = true;
    }
    switch (map.getId()) {
        case 932200100:
        case 932200300:
            toPortal = clear ? 3 : 16;
            break;
        case 932200200:
            toPortal = clear ? 5 : 1;
            break;
    }
    if (toPortal > 0) {
        player.teleportToPortalId(0, toPortal);
    }
    let finish = 0;
    for(let i = 0; i < members.length; i++){
        if (ranking[members[i].getName()] != null) {
            let memberName = members[i].getName();
            if(ranking[memberName]["LAP"] == maxLap)
            finish ++;
        }
    }
    if(finish >= event.getVariable("minSize")){
        event.stopTimer("prepareEndEvent");
        event.startTimer("prepareEndEvent", 0);
    }
    if(lap != maxLap){
        broadcastEventNotice(5, "玩家" + player.getName() + "完成了第" + lap + "圈。目前排名第" + (rank + 1) + "。");
        broadcastEventNotice(-2, "玩家" + player.getName() + "完成了第" + lap + "圈。目前排名第" + (rank + 1) + "。");
    } else {
        ranking[player.getName()]["RANK"] = rank;
        event.getVariable("score")[player.getId()] += (20 - rank + 1) * 10;
        broadcastEventNotice(5, "玩家" + player.getName() + "跑完了！此次排名第" + (rank + 1) + "。");
        broadcastEventNotice(-2, "玩家" + player.getName() + "跑完了！此次排名第" + (rank + 1) + "。");
    }
    
    //let currentRank = event.getVariable("currentRank");//当前是第几名

}

function formatDuring(mss) {
    var minutes = parseInt((mss % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = (mss % (1000 * 60)) / 1000;
    return  minutes + " 分 " + seconds + " 秒 ";
}

function broadcastEventNotice(type, msg) {
    let members = event.getVariable("members");
    for (let i = 0; i < members.length; i++) {
            members[i].dropMessage(type, msg);
    }
}

portal.abortWarp();
