/**
 * Event : 跑旗赛 - accept
 * @author Yukinoshita
 */

let em = npc.getEvent("event_manager");
let EXIT_MAP = 932200001; //正午
let EVENT_FIELD = 932200100;
let REWARD_MAP = 932200002;
let MAP_NAME = "正午雪原"
let mapType = 0;
updateMap();
let event = npc.getEvent("event_pqs");
let text = "#e跑旗赛：#n\r\n";
text += "奔跑吧！跳跃吧！跑旗赛就要开始啦！\r\n";
text += "活动状态:#e" + getEventStatus() + "#n 。#b\r\n\r\n";
text += (getEventStatus() == "#g等待中#k" ? "" + MAP_NAME + "" + (em.getVariable("pqsItem") == 1 ? "-道具赛" : "-竞速赛") + "" + em.getVariable("pqsMaxLap") + "圈\r\n#L0#我想参加跑旗赛！#l\r\n" : "");
text += "#L1#听取活动说明。#l\r\n";
text += "#L2#离开这里。#l\r\n";
if (player.isGm()) {
    text += "#L3#start event.#l\r\n";
    text += "#L4#end event.#l\r\n";
}
let selection = npc.askMenu(text);
if (selection == 0) {
    if (em.getVariable("pqs") == 0) {
        npc.say("活动还没有开始哦。");
    } else if (event.getVariable("started")) {
        npc.say("你来晚了，比赛已经开始了。");
    } else if (player.getChannel() != 1) {
        npc.say("活动只在1频道进行。");
    } else {
        player.setEvent(event);

        player.changeMap(EVENT_FIELD, 0);
        let members = event.getVariable("members");
        members.push(player);
        //player.showTimer((event.getVariable("waitTime") - new Date().getTime()) / 1000);
        //player.dropMessage(9, "正在等待其他玩家，目前 " + members.length + "/5人。");
    }
} else if (selection == 2) {
    player.removeBuffs();
    player.changeMap(910000000);

} else if (selection == 3) {
    em.setVariable("pqsMapIndex", npc.askMenu("选择开启的地图：\r\n#b#L0#正午雪原#l\r\n#L1#夕阳雪原#l\r\n#L2#深夜雪原#l"));
    em.setVariable("pqsItem", npc.askMenu("选择是否开启道具？\r\n#b#L1#开启#l\r\n#L0#关闭#l"));
    em.setVariable("pqsMaxLap", npc.askNumber("跑几圈？", 3, 1, 100));
    updateMap();
    em.setVariable("pqs", 2);
    npc.say("跑旗赛已开放。");
} else if (selection == 4) {
    em.setVariable("pqs", 0);
    if (event != null) {
        event.destroyEvent();
    }
    npc.say("跑旗赛已关闭。");
}

function updateMap() {
    switch (em.getVariable("pqsMapIndex")) {
        case 0:
            EXIT_MAP = 932200001; //正午
            EVENT_FIELD = 932200100;
            REWARD_MAP = 932200002;
            MAP_NAME = "正午雪原"
            break;
        case 1: //夕阳
            EXIT_MAP = 932200003;
            EVENT_FIELD = 932200200;
            REWARD_MAP = 932200004;
            mapType = 1;
            MAP_NAME = "夕阳雪原"
            break;
        case 2: //深夜
            EXIT_MAP = 932200005;
            EVENT_FIELD = 932200300;
            REWARD_MAP = 932200006;
            MAP_NAME = "深夜雪原"
            break;
    }
}

function getEventStatus() {
    if (em.getVariable("pqs") == 0) {
        return "#r未开始#k";
    } else {
        if (event == null) {
            if (npc.makeEvent("event_pqs", true, [em.getVariable("pqsItem"), mapType, EXIT_MAP, EVENT_FIELD, REWARD_MAP, em.getVariable("pqsMaxLap")]) != null) {
                em.setVariable("pqsRanking", {});
                event = npc.getEvent("event_pqs");
                return getEventStatus();
            } else {
                npc.say("event error.");
                return null;
            }

        } else {
            if (event.getVariable("started")) {
                return "#r进行中#k";
            } else {
                return "#g等待中#k"
            }
        }

    }
}