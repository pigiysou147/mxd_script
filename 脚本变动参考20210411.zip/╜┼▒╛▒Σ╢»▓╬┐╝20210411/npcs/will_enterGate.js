
let minPlayers = 1;
let maxPlayers = 6;
let minLevel = [235, 235];
let maxLevel = [275, 275];
let maxenter = [990, 99];
let BossName = ["威尔", "威尔[困难]"];
let PQLog = ["Will", "Will_Hard"];
let event = ["boss_will", "boss_will_hard"];
let onlyOne = true;
let startmap = 450007240;
if (map.getId() == startmap) {
    let text = "";
    for (let i = 0; i < BossName.length; i++) {
        text += "\r\n#b#L" + i + "##r<Boss：" + BossName[i] + ">进行入场申请#b#l#k";
    }
    let sel = npc.askMenuE("为了阻止威尔，想移动到#b衍射游廊#k吗？#b\r\n" + text, true);
    if (party == null || player.getId() != party.getLeader()) {
        npc.sayNextE("你需要有一个#r" + minPlayers + "~" + maxPlayers + "#k人的队伍.并且等级在" + minLevel[sel] + "~" + maxLevel[sel] + "范围,\r\n那么请让你的组队长和我对话吧!", true);
    } else if (party.numberOfMembersInChannel() < minPlayers || party.getMembersCount(map.getId(), 1, 500) > maxPlayers) {
        npc.sayNextE("你需要有一个#r" + minPlayers + "~" + maxPlayers + "#k人的队伍.!", true);
    } else if (party.getMembersCount(map.getId(), minLevel[sel], maxLevel[sel]) < minPlayers) {
        npc.sayNextE("你队员的等级要在" + minLevel[sel] + "~" + maxLevel[sel] + "范围!请确认!", true);
    } else if (party.getMembersCount(map.getId(), 1, 500) < party.getMembersCount()) {
        npc.sayNextE("好像有队员在其他地方，请把队员都召集到这里！", true);
    } else if (!party.isAllMembersAllowedPQ(PQLog[sel], maxenter[sel])) {
        npc.sayNextE("你队员#r#e" + party.getNotAllowedMember(PQLog[sel], maxenter[sel]) + "#n#k次数已经达到上限了。", true);
    } else if (npc.makeEvent(event[sel], onlyOne, party) == null) {
        npc.sayNextE("已经有队伍在进行了,请更换其他频道尝试。", true);
    }
} else {
    let ret = npc.askYesNoE("你想要现在就离开这里吗？", true);
    if (ret == 1) {
        player.changeMap(startmap);
    }
}
