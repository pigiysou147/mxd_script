/**
 * Event : 跑旗赛 - rank
 * @author Yukinoshita
 */

let rankReward = [
    [1, 2431302, 150],//宝物箱子
    [1, 2431303, 120],//神秘宝物箱子
    [1, 2048717, 5],//永远的涅槃火焰	
    [1, 5062024, 10],//闪炫魔方
    [1, 2431743, 3],//抵用券10000商品券
    [1, 2431048, 10],//卷轴箱
    [1, 3991006, 50000], //GP
    [1, 3991018, 1], //SP

    //[2,4034848,30],
    [2, 2048717, 3],//永远的涅槃火焰
    [2, 5062024, 5],//闪炫魔方
    [2, 2431743, 2],//抵用券10000商品券
    [2, 2431302, 100],
    [2, 2431303, 100],
    [2, 2431048, 9],//卷轴箱
    [2, 3991006, 40000], //GP
    [2, 3991018, 1], //SP

    //[3,4034848,15],
    [3, 5062024, 5],
    [3, 2048717, 2],
    [3, 2431743, 1],
    [3, 2431302, 100],
    [3, 2431303, 80],
    [3, 2431048, 8],//卷轴箱
    [3, 3991006, 30000], //GP
    [3, 3991018, 1], //SP

    [4, 5062024, 3],
    [4, 2048717, 1],
    [4, 2048716, 1],
    [4, 2431743, 1],
    [4, 2431302, 80],
    [4, 2431303, 50],
    [4, 2431048, 7],//卷轴箱
    [4, 3991006, 20000], //GP

    [5, 5062024, 3],
    [5, 2431302, 50],
    [5, 2431303, 50],
    [5, 2431743, 1],
    [5, 2048716, 1], 
    [5, 2431048, 6],//卷轴箱
    [5, 3991006, 20000], //GP
];

let outOfRank = 5;
let outOfRankReward = [
    [2431302, 30],
    [2431303, 30],
    [2431048, 3],
    [3991006, 10000], //GP
];

let unRankReward = [
    [2431303, 30],
    [2431048, 1],
    [3991006, 5000], //GP
]


let em = npc.getEvent("event_manager");
let event = npc.getEvent("event_pqs");
homePage:
while(true){
    let text = "#e本次跑旗赛排行榜：#n#b\r\n";
    if (em != null) {
        if (em.getVariable("pqsRanking") != {}) {
            let ranking = em.getVariable("pqsRanking");
            let index = 0;
            let playerCount = 0;
            for (let player in ranking)
                playerCount++;
            let rankIndex = 0;
            for (let i = 0; i < playerCount; i++) {//至少循环人数遍
                for (let player in ranking) {
                    if(ranking[player] == null){
                        continue;
                    }
                    if (ranking[player]["RANK"] == rankIndex) {//寻找完成的玩家的名次并排名
                        text += "#L" + rankIndex + "# 第 " + FormatString("0", 2, (rankIndex + 1)) + " 名 " + FormatString(" ", 12, player) + " TIME " + formatDuring(ranking[player]["PASTTIME"]) + "#l\r\n";
                        rankIndex++;
                        break;
                    }
                }
            }
            for (let player in ranking) {
                if(ranking[player] == null){
                    continue;
                }
                if (ranking[player]["RANK"] == 99) {
                    text += "#L" + rankIndex + "# 未完成 " + player + " TIME: --: -- . --#l\r\n";
                }
            }
            text += "\r\n#d";
            if (ranking[player.getName()] != null) {
                if(ranking[player.getName()]["REWARDED"] == null){
                    if (ranking[player.getName()]["RANK"] != -1) {
                        text += "#L100#领取排名奖励。#l\r\n";
                    } else {
                        text += "#L101#领取安慰奖。#l\r\n";
                    }
                }
    
            }
            text += "#L104#查看历史排名。#l\r\n";
            text += "#L102#查看各名次奖励。#l\r\n";
            text += "#L103#出去。#l\r\n";
    
        }
    }
    
    let selection = npc.askMenu(text);
    let playerRank = -2;
    if(em.getVariable("pqsRanking")[player.getName()] != null){
        playerRank = em.getVariable("pqsRanking")[player.getName()]["RANK"];
    }
    
    
    text = "";
    switch (selection) {
        default:
            npc.say("这个功能还在坑里。");
            break;
        case 100:
            if (playerRank < outOfRank && playerRank != -1) {
                text += "#e获得了第" + (playerRank + 1) + "名的奖励！#n\r\n";
                for (let i in rankReward) {
                    if ((rankReward[i][0] - 1) == playerRank) {                    
                        gainItem(rankReward[i][1], rankReward[i][2]);
                        text += "#v" + rankReward[i][1] + "##b#z" + rankReward[i][1] + "##k * " + rankReward[i][2] + "\r\n";
                    }
                }
            } else if (playerRank >= outOfRank) {
                text += "#e获得了鼓励奖！下次再加把劲。#n\r\n";
                for (let i in outOfRankReward) {
    
                    gainItem(outOfRankReward[i][0], outOfRankReward[i][1]);
                    text += "#v" + outOfRankReward[i][0] + "##b#z" + outOfRankReward[i][0] + "##k * " + outOfRankReward[i][1] + "\r\n";
    
                }
            } else {
                npc.say("?");
            }
            em.getVariable("pqsRanking")[player.getName()]["REWARDED"] = true;
            npc.say(text);
            break;
        case 101:
            if (playerRank == -1) {
                text += "#e获得了参与奖！多多练习吧。#n\r\n";
                for (let i in unRankReward) {
                    gainItem(unRankReward[i][0], unRankReward[i][1]);
                    text += "#v" + unRankReward[i][0] + "##b#z" + unRankReward[i][0] + "##k * " + unRankReward[i][1] + "\r\n";
                }
                em.getVariable("pqsRanking")[player.getName()]["REWARDED"] = true;
                npc.say(text);
            }
            break;
        case 102:
            viewReward:
            while(true){
                text = "选择想要查看的名次：\r\n#b";
                let viewIndex = 0;
                for(viewIndex = 0; viewIndex < outOfRank; viewIndex++){
                    text += "#L" + viewIndex + "#查看第 #e" + (viewIndex + 1) + "#n 名的奖励。#l\r\n";
                }
                //viewIndex++;
                text += "#L" + viewIndex + "#查看" + viewIndex++ + "之后排名的奖励。#l\r\n";
                text += "#L" + viewIndex++ + "#查看安慰奖。#l\r\n";
                text += "#L" + viewIndex++ + "#返回首页。#l";
                let selView = npc.askMenu(text);
                if(selView < outOfRank){
                    text = "#e查看" + (selView + 1) + "名的奖励：#n\r\n\r\n"
                    for (let i in rankReward) {
                        if ((rankReward[i][0] - 1) == selView) {                    
                            text += "#v" + rankReward[i][1] + "##b#z" + rankReward[i][1] + "##k * " + rankReward[i][2] + "\r\n";
                        }
                    }
                } else if(selView == outOfRank){
                    text = "#e查看" + selView + "名后的奖励：#n\r\n\r\n"
                    for (let i in outOfRankReward) {
                        text += "#v" + outOfRankReward[i][0] + "##b#z" + outOfRankReward[i][0] + "##k * " + outOfRankReward[i][1] + "\r\n";
                    }
                } else if(selView == outOfRank + 1){
                    text = "#e查看参与奖的奖励：#n\r\n\r\n"
                    for (let i in unRankReward) {
                        text += "#v" + unRankReward[i][0] + "##b#z" + unRankReward[i][0] + "##k * " + unRankReward[i][1] + "\r\n";
                    }
                } else {
                    break viewReward;
                }
                npc.sayNext(text);    
            }
            break;
        case 103:
            player.changeMap(932200001, 0);
            break homePage;
            break;
    }
    
}

function formatDuring(mss) {
    var minutes = parseInt((mss % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = (mss % (1000 * 60)) / 1000;
    return minutes + ": " + seconds + "";
}

function FormatString(c, length, str) {
    if (str.length < length) {
        let strlength = str.length;
        for (var i = str.length; i < length; i++) {
            //player.dropMessage(1,"!" + (i - strlength) + " is " + str[i - strlength]);
            if (str.charCodeAt(i - strlength) >= 0 && str.charCodeAt(i - strlength) <= 128 && (i - strlength) < strlength) {// && (strlength - i) < 0
                //player.dropMessage(1,"?" + (i - strlength) + " is " + str[i - strlength]);
                str += "　";
                str += " ";
            } else {
                str += "　";

            }
        }
    }
    return str;
}

function gainItem(itemId, qty) {
    if (itemId == 3991006) {
        if (player.getGuildId() > 0) {
            player.gainGP(qty);
        }
    } else if(itemId == 3991018) {
        if (player.getGuildId() > 0) {
            player.gainGuildSP(qty);
        }
    } else {
        player.gainItem(itemId, qty);
    }
}