

/**
 * Content: Dream Break
 * @author Yukinoshita
 */

let EXIT_MAP = 921171100;
let FIELD = 921171000;

let BOSS_LOG = "DreamBreak";
let DREAM_DEEP_BASE = 500; //梦境深度初始
let DREAM_DEEP_RATE = 10; //噩梦深度变动倍率
let MOB_BASE_HP = 100000000000; //怪物基础血量
let SLEEP_MUSICBOX_HP_RATE = 50; //噩梦音乐盒血量倍率
let MUSIC_BOX_HP = 10000000; //音乐盒血量
let DREAM_POINT_REWARD = 200; //梦境点数奖励
let MOB_COUNT = 5; //每个房间初始怪物数量
let MAX_MOB_SIZE = 50; //怪物最大数量


let startTime = new Date().getTime();
let checkDreak_lock = false;
let blockDream = false;
let dreamDeep = DREAM_DEEP_BASE;
let mobHp = MOB_BASE_HP;
let player;
let endTime;
let stage = 1;
let clearTime = 0;
let mapPoints = [[842, -457], [805, -1963],
[3167, -237], [833, 1485], [-1351, -237]];

let time = 10 * 60 * 1000; //每个stage的时间

function init(attachment) {
        player = attachment;
        player.changeMap(FIELD);

        let map = event.getMap(FIELD);
        map.clearMobs();

        //event.startTimer("kick", time);
        //endTime = new Date().getTime() + time;
        event.startTimer("loadStage", 3000);
        player.setEvent(event);
}

function mobDied(mob) {
        //破坏梦境盒子 - 睡眠音乐盒 -50 噩梦深度，噩梦音乐盒+50噩梦深度
        let newMobId = mob.getDataId();
        let isNightmare = false;
        switch (mob.getDataId()) {
                case 9833070://睡眠音乐盒
                case 9833071://
                case 9833072://
                case 9833073://
                case 9833074://
                        newMobId += 10;
                        dreamDeep += 50;
                        break;
                case 9833080://噩梦音乐盒
                case 9833081://
                case 9833082://
                case 9833083://
                case 9833084://
                        isNightmare = true;
                        newMobId -= 10;
                        dreamDeep -= 50;
                        break;
        }
        if (newMobId != mob.getDataId()) {
                let map = event.getMap(FIELD);
                newMob = map.makeMob(newMobId);//生成音乐盒
                newMob.changeBaseHp(isNightmare ? MOB_BASE_HP * SLEEP_MUSICBOX_HP_RATE : MUSIC_BOX_HP)
                newMob.setKeepAggro(true);
                newMob.disableSpawnRevives();
                map.spawnMob(newMob, mob.getMob().getPosition().x, mob.getMob().getPosition().y);
                newMob.getMob().sendSpawnData(player.getPlayer().getClient())
                newMob.getMob().setController(player.getPlayer());
        }
}

function removePlayer(changeMap) {
        player.setEvent(null);
        event.destroyEvent();
        if (changeMap) {
                player.changeMap(EXIT_MAP);
        }
}

function playerDisconnected(player) {
        //changeMap is false since all PQ maps force return the player to the exit
        //map on his next login anyway, and we don't want to deal with sending
        //change map packets to a disconnected client
        removePlayer(false);
}

function playerChangedMap(player, destination) {
        //TODO: is it true that even when a non-leader clicks Nella, the entire
        //party is booted? and that GMS forces party out when only two members
        //remain alive and online?
        switch (destination.getId()) {
                case FIELD:
                        player.showDeathCount();
                        break;
                default:
                        //player died and respawned or clicked Nella to leave PQ
                        //changeMap is false so player doesn't get re-warped to exit map
                        removePlayer(false);
        }
}



function kick() {
        player.setEvent(null);
        player.changeMap(EXIT_MAP);
        event.destroyEvent();
}

function timerExpired(key) {
        switch (key) {
                case "kick":
                        event.stopTimer("checkDream");
                        event.stopTimer("loadStage");
                        event.stopTimer("spawnMob");
                        kick();
                        break;
                case "loadStage":
                        loadStage();
                        break;
                case "checkDream":
                        checkDream();
                        event.startTimer("checkDream", 3000);
                        break;
                case "spawnMob":
                        spawnMob();
                        break;
                case "blockDream":
                        if (!blockDream) {
                                blockDream = true;
                                event.startTimer("blockDream", 20000);
                        } else {
                                blockDream = false;
                        }
                        break;
        }
}

function deinit() {
        player.setEvent(null);
}


/*
 * 梦境阶段信息载入
 * @param {type} eim
 * @returns {undefined}
 */
function loadStage() {
        let map = event.getMap(FIELD);
        player.updateQuestRecordEx(15901, "stage", stage);

        map.updateDreamBreakInfo(0x03, DREAM_DEEP_BASE, time, stage);//载入UI信息
        map.updateDreamBreakInfo(0x06, 1, time, 0);//暂停计时
        map.updateDreamBreakInfo(0x05, stage, 0, 0);//开始倒计时
        dreamDeep = DREAM_DEEP_BASE;
        mobHp = MOB_BASE_HP * stage * ((stage - stage % 10) / 10 + 1);
        player.showProgressMessageFont("通过次元缝隙，消灭位于各个房间的噩梦音乐盒！", 0x14, 0x14, 0, 0)
        //等待3秒后生成怪物
        event.startTimer("spawnMob", 3000);
}

function spawnMob() {
        let map = event.getMap(FIELD);
        map.reset();
        //随机生成怪物 - 5个地区，随机3个地区生成噩梦音乐盒 - 0为中央，1为上，2为下，3为左，4为右
        let rand1 = Math.floor(Math.random() * 5);//生成沉睡音乐盒地区 - 中央的那一个必定为睡眠音乐盒
        var rand2 = rand1;
        let loop = 0;
        while (loop < 10000) {
                rand2 = Math.floor(Math.random() * 5);
                if (rand2 != rand1) {
                        break;
                }
                loop++;
        }
        for (let i = 0; i < mapPoints.length; i++) {
                let point = mapPoints[i];
                let spawnMusic = 9833070 + i;//睡眠音乐盒
                let isSleep = false;
                if ((i != rand1) && (i != rand2)) {
                        spawnMusic += 10;//噩梦音乐盒
                        isSleep = true;
                }
                let mob = map.makeMob(spawnMusic);//生成音乐盒
                mob.changeBaseHp(isSleep ? MOB_BASE_HP * SLEEP_MUSICBOX_HP_RATE : MUSIC_BOX_HP)
                mob.setKeepAggro(true);
                mob.disableSpawnRevives();
                map.spawnMob(mob, point[0], point[1]);
                mob.getMob().sendSpawnData(player.getPlayer().getClient())
                mob.getMob().setController(player.getPlayer());

                for (let u = 0; u < MOB_COUNT; u++) {
                        let mob1 = map.makeMob(9833090 + Math.floor(Math.random() * 10));
                        mob1.changeBaseHp(MOB_BASE_HP);
                        mob1.setKeepAggro(true);
                        map.spawnMob(mob1, point[0] + Math.floor(Math.random() * 100) - Math.floor(Math.random() * 100), point[1]);
                        mob1.getMob().sendSpawnData(player.getPlayer().getClient())
                        mob1.getMob().setController(player.getPlayer());
                }
        }
        clearTime = new Date().getTime() + time;
        map.updateDreamBreakInfo(0x06, 0, time * 1000, 0);//开始计时
        map.updateDreamBreakInfo(0x04, dreamDeep, 0, 0);//载入噩梦深度
        player.teleportToPortalId(0, 9);
        //开启检测线程
        checkDreak_lock = false;
        event.startTimer("checkDream", 3000);
}


function checkDream() {
        if (checkDreak_lock) {
                return;
        }
        if (new Date().getTime() > clearTime) {
                kick();
                return;
        }

        //获取当前地图噩梦音乐盒数量
        let map = event.getMap(FIELD);
        let sleepMusic = 0;
        for (let i = 0; i < 5; i++) {
                let mob = map.getMobById(9833080 + i);
                if (mob != null) {
                        sleepMusic++;
                        //if (mob.getMob().getController() == null || !mob.getMob().isControllerHasAggro()) {
                        mob.getMob().setKeepAggro(true);
                        mob.getMob().setControllerHasAggro(true);
                        if (mob.getMob().getController() == null) {
                                mob.getMob().setController(player.getPlayer());
                        }
                        //}
                }
        }
        for (var i = 0; i < 5; i++) {
                var mob = map.getMobById(9833070 + i);
                if (mob != null) {
                        //if (mob.getMob().getController() == null || !mob.getMob().isControllerHasAggro()) {
                        mob.getMob().setKeepAggro(true);
                        mob.getMob().setControllerHasAggro(true);
                        if (mob.getMob().getController() == null) {
                                mob.getMob().setController(player.getPlayer());
                        }

                        //}
                }
        }

        if (!blockDream) {
                //player.dropMessage(3, "深度信息更新，过去：" + dreamDeep);
                dreamDeep += DREAM_DEEP_RATE * sleepMusic - DREAM_DEEP_RATE * (5 - sleepMusic);
                dreamDeep = Math.min(1000, Math.max(0, dreamDeep));
                //player.dropMessage(3, "深度信息更新，现在：" + dreamDeep);
                map.updateDreamBreakInfo(0x04, dreamDeep, 0, 0);//载入噩梦深度
                if (dreamDeep >= 1000) {//噩梦深度达到1000以上，结束
                        player.dropMessage(3, "失败了。");
                        kick();
                        return;
                } else if (dreamDeep <= 0) {//噩梦深度为0，统计结果开启下一阶段
                        if (checkDreak_lock) {
                                return;
                        }
                        checkDreak_lock = true;
                        nextStage();
                        event.stopTimer("checkDream");
                        return;
                }
        }

        //再每一个地点生成一只怪物 - 先判断当前地图怪物总数量
        let mobsize = map.getEventMobCount();
        if (MAX_MOB_SIZE > mobsize) {
                for (let i = 0; i < mapPoints.length; i++) {
                        let point = mapPoints[i];
                        let mob1 = map.makeMob(9833090 + Math.floor(Math.random() * 10));
                        mob1.changeBaseHp(MOB_BASE_HP);
                        mob1.setKeepAggro(true);
                        map.spawnMob(mob1, point[0] + Math.floor(Math.random() * 100) - Math.floor(Math.random() * 100), point[1]);
                        mob1.getMob().sendSpawnData(player.getPlayer().getClient())
                        mob1.getMob().setController(player.getPlayer());

                }
        }

}

function nextStage() {
        let leftTime = clearTime - new Date().getTime();
        let map = event.getMap(FIELD);
        map.updateDreamBreakInfo(0x06, 1, leftTime, 0);//暂停计时
        leftTime = (leftTime - leftTime % 1000) / 1000;//转换成秒
        player.updateQuestRecordEx(15901, "clearTime", Math.floor((new Date().getTime() - clearTime + time) / 1000));
        let current = player.getIntQuestRecordEx(15901, "dream");
        player.updateQuestRecordEx(15901, "dream", current + DREAM_POINT_REWARD);
        player.showProgressMessageFont("梦之点数获得" + DREAM_POINT_REWARD + "点！" + (current + DREAM_POINT_REWARD), 0x14, 0x14, 0, 0);
        // eim.broadcastPacket(OtherPacketCreator.UseRuneMsg("梦之点数获得" + dreamPointRew + "点！", 0x14, 0x14));

        //发送统计结果
        map.updateDreamBreakInfo(0x07, Math.floor((new Date().getTime() - clearTime + time) / 1000), 0, 0);//
        map.reset();
        stage++;
        event.startTimer("loadStage", 5000);
}