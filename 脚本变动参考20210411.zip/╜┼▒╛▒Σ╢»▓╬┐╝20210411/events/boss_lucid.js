/**
 * Boss: Lucid 路西德
 * @author NautMS
 */

let EXIT_MAP = 450004000;

let PHASE_1_DIR = 450004100;
let PHASE_1 = 450004150;

let PHASE_2_DIR = 450004200;
let PHASE_2 = 450004250;

let PHASE_3 = 450004300;

let DEATH_COUNT = 5;

let BOSS_LOG = "Lucid";
let party;
let members;
let endTime;

function init(attachment) {
    party = attachment;

    let map_1 = event.getMap(PHASE_1);
    let map_2 = event.getMap(PHASE_2);
    let map_3 = event.getMap(PHASE_3);

    map_1.reset();
    map_2.reset();
    map_3.reset();

    party.changeMap(PHASE_1_DIR, 0);
    members = party.getLocalMembers();

    map_1.showTimer(30 * 60);
    event.setVariable("butterflySpeedStep", 1);
    event.setVariable("lastHPPercent", 10);

    event.startTimer("kick", 30 * 60 * 1000);
    endTime = new Date().getTime() + 30 * 60 * 1000;

    event.setVariable("members", members);
    for (let i = 0; i < members.length; i++) {
        members[i].setEvent(event);
        members[i].addPQLog(BOSS_LOG, 1, 3);
        members[i].setDeathCount(DEATH_COUNT);
    }
}

function mobDied(mob) {
    switch (mob.getDataId()) {
        case 8880140://1阶段 路西德
            event.setVariable("boss1", true);
            event.stopTimer("ButterflyPhase1");
            event.startTimer("To_Stage_2", 4000);
            break;
        case 8880150://2阶段 路西德
            event.setVariable("boss2", true);
            event.startTimer("To_Stage_3", 4000);
            event.stopTimer("ButterflyPhase2");
            break;
    }
}

function removePlayer(playerId, changeMap) {
    for (let i = 0; i < members.length; i++) {
        if (members[i].getId() == playerId) {
            //dissociate event before changing map so playerChangedMap is
            //not called and this method is not called again by the player
            members[i].setEvent(null);
            if (changeMap)
                members[i].changeMap(EXIT_MAP, "st00");
            //collapse the members array so we don't accidentally warp
            //this member again if the leader leaves later.
            members.splice(i, 1);
            break;
        }
    }
    if (members.length <= 0) {
        event.destroyEvent();
    }
}

function playerDisconnected(player) {
    //changeMap is false since all PQ maps force return the player to the exit
    //map on his next login anyway, and we don't want to deal with sending
    //change map packets to a disconnected client
    removePlayer(player.getId(), false);
}

function playerChangedMap(player, destination) {
    //TODO: is it true that even when a non-leader clicks Nella, the entire
    //party is booted? and that GMS forces party out when only two members
    //remain alive and online?
    switch (destination.getId()) {
        case PHASE_1_DIR:
        case PHASE_2_DIR:
        case PHASE_1:
        case PHASE_2:
        case PHASE_3:
            player.showTimer((endTime - new Date().getTime()) / 1000);
            player.showDeathCount();
            break;
        default:
            //player died and respawned or clicked Nella to leave PQ
            //changeMap is false so player doesn't get re-warped to exit map
            removePlayer(player.getId(), false);
    }
}

function partyMemberDischarged(party, player) {
    if (party.getLeader() == player.getId()) {
        kick();
    } else {
        removePlayer(player.getId(), true);
    }
}

function mobHit(player, mob, damage) {
    let map = event.getMap(PHASE_2);
    switch (mob.getDataId()) {
        case 8880140:
            map = event.getMap(PHASE_1);
        case 8880150:
            checkLucidHp(mob, map);
            break;
    }
}

function kick() {
    for (let i = 0; i < members.length; i++) {
        //dissociate event before changing map so playerChangedMap is not
        //called and this method is not called again by the player
        members[i].setEvent(null);
        members[i].changeMap(EXIT_MAP);
    }
    event.destroyEvent();
}

function warpToMap(map, portal) {
    for (let i = 0; i < members.length; i++) {
        members[i].changeMap(map, portal);
    }
}

function timerExpired(key) {
    switch (key) {
        case "kick":
            kick();
            break;
        case "To_Stage_2":
            event.setVariable("butterflySpeedStep", 1);
            event.setVariable("lastHPPercent", 10);
            warpToMap(PHASE_2_DIR, 0);
            break;
        case "To_Stage_3":
            event.startTimer("kick", 5 * 60 * 1000);
            endTime = new Date().getTime() + 5 * 60 * 1000;
            warpToMap(PHASE_3, 0);
            break;
        case "ButterflyPhase1":
            event.getMap(PHASE_1).onLucidButterfly();
            event.startTimer("ButterflyPhase1", 4000 - event.getVariable("butterflySpeedStep") * 500);
            break;
        case "ButterflyPhase2":
            event.getMap(PHASE_2).onLucidButterfly();
            event.getMap(PHASE_2).brokenLucidSteps();
            event.startTimer("ButterflyPhase2", 4000 - event.getVariable("butterflySpeedStep") * 500);
            break;
    }
}


function checkLucidHp(mob, map) {
    let speedStep = event.getVariable("butterflySpeedStep"); //蝴蝶会跟随血量越来越快
    if (mob.getHPPercent() <= 50 && mob.getHPPercent() > 35 && speedStep != 2) {
        event.setVariable("butterflySpeedStep", 2);
    } else if (mob.getHPPercent() <= 35 && speedStep != 3) {
        event.setVariable("butterflySpeedStep", 3);
    }
    if (mob.getHPPercent() != 100 && Math.floor(mob.getHPPercent() / 10) + 1 != event.getVariable("lastHPPercent")) { //每10%血量增加一次喇叭机会
        event.setVariable("lastHPPercent", Math.floor(mob.getHPPercent() / 10) + 1);
        map.changeHornState(true);
    }

}

function deinit() {
    for (let i = 0; i < members.length; i++) {
        members[i].setEvent(null);
        members[i].setDeathCount(-1);
    }
}