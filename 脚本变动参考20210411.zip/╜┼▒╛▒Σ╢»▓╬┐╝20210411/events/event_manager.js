/**
 * Event Manager
 * @author Yukinoshita
 * @description 专用事件管理器
 */
let date = new Date();
let sec = date.getSeconds();

//status == 0 关闭，1自动开启（超时会关闭），2手动开启（超时不会自动关闭。）
function init(attachment) {
    event.setVariable("pqs", 0); //跑旗赛的status
    event.setVariable("pqsRanking", {}); //跑旗赛的rank暂存
    event.startTimer("checkEvent", (60 - sec) * 1000);

}



function timerExpired(key) {
    event.startTimer("checkEvent", (60 - sec) * 1000);
    date = new Date();
    sec = date.getSeconds();
    let week = date.getDay();
    let day = date.getDate();
    let hour = date.getHours();
    let min = date.getMinutes();
    switch (key) {
        case "checkEvent":
            //closeAll();
            if ((week == 5 || week == 6 || week == 0) && hour == 21 && min == 30) { //每周567晚上9点半自动启动
                event.startTimer("pqs", 30 * 60 * 1000);//30分钟后关闭
                event.setVariable("pqs", 1);
                let useItem = 1;
                switch (week) {
                    case 6: //周六不启动道具赛
                        useItem = 0;
                        break;
                }
                let mapIndex = Math.floor(Math.random() * 3);
                let mapType = 0;
                let maxLap = 3;
                switch (mapIndex) {
                    case 1: //夕阳地图mapType一定为1，圈数为5
                        mapType = 1;
                        maxLap = 5;
                        break;
                }
                event.setVariable("pqsItem", useItem);
                event.setVariable("pqsMapType", mapType);
                event.setVariable("pqsMapIndex", mapIndex);
                event.setVariable("pqsMaxLap", maxLap);
                event.broadcastPlayerNotice(1, "[跑旗赛] 跑旗赛开始啦！请前往自由市场绿水灵加入。");
                event.broadcastPlayerNotice(1, "[跑旗赛] 跑旗赛开始啦！请前往自由市场绿水灵加入。");
            }

            break;
        case "pqs":
            event.setVariable("pqs", 0);
            break;
        case "bingo":
            break;
        default:
            if (event.getVariable(key) == 1) {
                event.setVariable(key, 0);
            } else {
                event.broadcastPlayerNotice(1, "[Event Manager]Unexpected timer [" + key + "],please report GM.");
            }
            break;
    }
}


function deinit() {
    //do nothing
}
