/**
 * Event : 跑旗赛
 * @author Yukinoshita
 */

let EXIT_MAP = 932200001;
let EVENT_FIELD = 932200100;
let REWARD_MAP = 932200002;
let ranges_1 = [
    [0, 0, [-2756, 2558], [-2037, 2100]],

    [1, 10, [-2036, 2558], [-638, 2100]],
    [2, 10, [-639, 2678], [956, 2100]],
    [3, 20, [957, 2798], [2666, 1900]],
    //上层
    [4, 10, [1204, 1900], [2666, 1100]],
    [5, 10, [-650, 1900], [1203, 1100]],
    [6, 10, [-2036, 1900], [-651, 1100]],
    [7, 30, [-2756, 2150], [-2037, 1100]],
];
let ranges_2 = [
    [0, 0, [-1136, 2498], [2396, 1838]],

    [1, 50, [15, 1427], [2396, 1000]],
    [2, 50, [-1136, 1058], [-472, 950]],

];
let item_pos_1 = [
    [-1262, 2618], [-888, 2618], [545, 2435], [1068, 2092], [818, 2050], [2102, 2018], [2301, 1358],
    [1483, 1538], [395, 1118], [-257, 1358], [-773, 1238], [-1929, 1778], [-1377, 1778], [-2612, 1434], [-2612, 2138]
];
let item_pos_2 = [
    [-682, 2198], [-74, 2198], [34, 2498], [332, 2127], [620, 2078], [905, 2558], [1216, 2011],
    [1924, 2498], [2355, 2558], [1754, 1418], [1981, 1178], [669, 1118], [-351, 1238], [-1055, 1058], [-29, 1778]
];
let minPlayer = 5;
let members = [];
let endTime;
let lastMemberLength = 0;
let useItem = true;
let mapType = 0;
let maxLap = 3;

function init(attachment) {
    [useItem, mapType, EXIT_MAP, EVENT_FIELD, REWARD_MAP, maxLap] = attachment;
    event.setVariable("started", false);
    event.setVariable("members", members);
    event.setVariable("ranking", {});
    event.setVariable("currentRank", 0);
    event.setVariable("startTime", 0);
    event.setVariable("bestLapTime", { player: "CPU", time: 2147483647 }); //todo read from db
    event.setVariable("range", {});
    event.setVariable("score", {});
    event.setVariable("itemCount", {});
    event.setVariable("minSize", minPlayer);
    event.setVariable("useItem", useItem);
    event.setVariable("mapType", mapType);
    event.setVariable("maxLap", maxLap);

    let map = event.getMap(EVENT_FIELD);
    map.showTimer(30 * 60);//30分钟等待其他玩家。
    event.startTimer("destroyEvent", 30 * 60 * 1000);//30分钟人数不满就销毁EVENT。
    event.startTimer("checkMembers", 1000); //1秒检查一次加入的玩家数。
    waitTime = new Date().getTime() + 30 * 60 * 1000;
    event.setVariable("waitTime", waitTime);
}

function removePlayer(playerId, changeMap) {
    for (let i = 0; i < members.length; i++) {
        if (members[i].getId() == playerId) {
            //dissociate event before changing map so playerChangedMap is
            //not called and this method is not called again by the player
            members[i].setEvent(null);
            members[i].dropMessage(1, "exit event.");
            members[i].setActionBar(0);
            //if(event.getVariable("lockRank") != true) {
            //        event.getVariable("ranking")[members[i].getName()] = null;
            //}
            if (changeMap)
                members[i].changeMap(EXIT_MAP, "st00");
            //collapse the members array so we don't accidentally warp
            //this member again if the leader leaves later.
            members.splice(i, 1);
            break;
        }
    }
    //if (members.length <= 0) {
    //       event.destroyEvent();
    //}

}
function playerDisconnected(player) {
    //changeMap is false since all PQ maps force return the player to the exit
    //map on his next login anyway, and we don't want to deal with sending
    //change map packets to a disconnected client
    removePlayer(player.getId(), false);
}

/**
 * 
 * @param {ScriptPlayer} player 
 * @param {ScriptField} destination 
 */
function playerChangedMap(player, destination) {
    if (destination.getId() != EVENT_FIELD) {
        removePlayer(player.getId(), false);
    } else {
        //player.dropMessage(1, "[DEBUG]:map changed to " + destination.getId() + "。");
        player.showTimer((endTime - new Date().getTime()) / 1000);
        player.setActionBar(0x16);
        player.dropMessage(9, "请稍等，跑旗赛就要开始啦！");
        broadcastEventNotice(9, player.getName() + "加入了跑旗赛！目前 " + members.length + "" + (members.length <= minPlayer?"/" + minPlayer + "":"") + "人。");
    }

}

function playerPickupItem(player, map, itemId) {
    player.dropMessage(6, "DEBUG:itemId:" + itemId + "picked.");
    let useCount = 1;
    let skillId = 0;
    switch (itemId) {
        case 2023295:// - 重甲防御
            skillId = 80001415;
            break;
        case 2023296:// - 超高跳
            skillId = 80001416;
            break;
        case 2023297:// - 冲锋
            skillId = 80001417;
            break;
        case 2023298:// - 发射大炮
            skillId = 80001418;
            break;
    }
    if (skillId > 0) {
        if (event.getVariable("itemCount")[player.getId()] == null) {
            event.getVariable("itemCount")[player.getId()] = {};
        }
        player.dropMessage(3, "获得道具" + itemId + "，过去数量" + event.getVariable("itemCount")[player.getId()][itemId] + "")
        if (event.getVariable("itemCount")[player.getId()][itemId] == null) {
            event.getVariable("itemCount")[player.getId()][itemId] = useCount;
        } else {
            event.getVariable("itemCount")[player.getId()][itemId] += useCount;
        }
        player.dropMessage(3, "获得道具" + itemId + "，现在数量" + event.getVariable("itemCount")[player.getId()][itemId] + "")
        player.updateActionBar(0x0B, 0x16, itemId, event.getVariable("itemCount")[player.getId()][itemId]);
    }
    let rItemId = 0;
    switch (itemId) {
        case 80001415:
            rItemId = 2023295;
            break;
        case 80001416:
            rItemId = 2023296;
            break;
        case 80001417:
            rItemId = 2023297;
            break;
        case 80001418:
            rItemId = 2023298;
            break;
    }
    if (rItemId > 0) {
        if (event.getVariable("itemCount")[player.getId()] == null) {
            event.getVariable("itemCount")[player.getId()] = {};
        }
        player.dropMessage(3, "消耗道具" + rItemId + "，过去数量" + event.getVariable("itemCount")[player.getId()][rItemId] + "")
        if (event.getVariable("itemCount")[player.getId()][rItemId] == null) {
            event.getVariable("itemCount")[player.getId()][rItemId] = 0;
        } else {
            let count = event.getVariable("itemCount")[player.getId()][rItemId];
            count = Math.max(0, count - 1);
            event.getVariable("itemCount")[player.getId()][rItemId] = count;

        }
        player.dropMessage(3, "消耗道具" + rItemId + "，现在数量" + event.getVariable("itemCount")[player.getId()][rItemId] + "")
        player.updateActionBar(0x0B, 0x16, rItemId, event.getVariable("itemCount")[player.getId()][rItemId]);
    }

}

function kick() {
    for (let i = 0; i < members.length; i++) {
        //dissociate event before changing map so playerChangedMap is not
        //called and this method is not called again by the player
        members[i].setEvent(null);
        members[i].changeMap(EXIT_MAP);
    }
    event.destroyEvent();
}

function timerExpired(key) {
    switch (key) {
        case "destroyEvent":
            event.destroyEvent();
            break;
        case "checkMembers":
            if (members.length >= minPlayer) {
                if (event.getVariable("readyStart") == null) {
                    event.setVariable("readyStart", true);
                    broadcastEventNotice(-2, "即将开始跑旗赛，还有1分钟时间等待其他玩家。");
                    broadcastEventNotice(9, "即将开始跑旗赛，还有1分钟时间等待其他玩家。");
                    event.broadcastPlayerNotice(1, "[跑旗赛]还有1分钟，跑旗赛就要开始了，没有集合的小伙伴抓紧啦。");
                    event.startTimer("startEvent", 60 * 1000); //最后等待1分钟开始活动。
                    event.getMap(EVENT_FIELD).showTimer(60);
                    event.setVariable("waitTime", new Date().getTime() + 60 * 1000);

                }
            } else {

                event.startTimer("checkMembers", 1000);

            }
            if (members.length != lastMemberLength) {
                broadcastEventNotice(-2, "正在等待其他玩家，目前 " + members.length + "/" + minPlayer + "人。");
                lastMemberLength = members.length;
                event.startTimer("checkMembers", 1000);
            }
            break;
        case "startEvent":
            event.getMap(EVENT_FIELD).showFieldRank(20);
            calcRank(true);
            if (useItem) {
                event.startTimer("spawnDrop", 1000);
            }
            event.startTimer("calcRank", 3000);
            event.setVariable("started", true);
            event.setVariable("startTime", new Date().getTime());
            broadcastEventNotice(-2, "跑旗赛开始啦！");
            broadcastEventNotice(9, "跑旗赛开始啦！");

            event.getMap(EVENT_FIELD).showTimer(15 * 60);
            event.startTimer("prepareEndEvent", 15 * 60 * 1000);
            break;
        case "prepareEndEvent":
            if (event.getVariable("prepareEndEvent") != true) {
                event.setVariable("prepareEndEvent", true);
                event.getMap(EVENT_FIELD).showTimer(60);
                event.startTimer("endEvent", 60 * 1000);
                broadcastEventNotice(-2, "距离跑旗赛结束还有60秒，抓紧时间！");
                broadcastEventNotice(9, "距离跑旗赛结束还有60秒，抓紧时间！");
            }
            break;
        case "endEvent":
            //event.setVariable("lockRank", true);
            while (members.length != 0) {
                members[0].changeMap(REWARD_MAP, 0);
            }
            event.setVariable("started", false);
            event.broadcastPlayerNotice(1, "[跑旗赛]已经结束，欢迎下次参加。");
            event.destroyEvent();
            //event.startTimer("destroyEvent", 10000);
            break;
        case "calcRank":
            calcRank(false);
            event.startTimer("calcRank", 3000);
            break;
        case "spawnDrop":
            spawnDrop();
            event.startTimer("spawnDrop", 20000);
            break;
    }
}

function calcRank(init) {
    let ls = [];
    if (!init) {
        let ranges = mapType == 0 ? ranges_1 : ranges_2;
        for (let i = 0; i < members.length; i++) {
            let chr = members[i];
            //判断角色所在位置点 计算积分
            let pos_ = chr.getPosition();
            let pos_x = pos_.x;
            let pos_y = pos_.y;
            let range_chr_ = event.getVariable("range")[chr.getId()] == null ? 0 : event.getVariable("range")[chr.getId()];
            let add_score = 0;
            let range_new = 0;
            for (let j = range_chr_; j < ranges.length; j++) {
                if (pos_x >= ranges[j][2][0] && (pos_x <= ranges[j][3][0]) && (pos_y <= ranges[j][2][1]) && (pos_y >= ranges[j][3][1])) {
                    range_new = j;
                    break;
                } else {
                    add_score += ranges[j][1];
                }
            }
            if (range_new > range_chr_) {
                event.getVariable("range")[chr.getId()] = range_new;
                if (add_score > 0) {
                    let score_chr_ = event.getVariable("score")[chr.getId()] == null ? 0 : event.getVariable("score")[chr.getId()];
                    event.getVariable("score")[chr.getId()] = (score_chr_ + add_score);
                }
            }
            ls.push([chr.getId(), event.getVariable("score")[chr.getId()] == null ? 0 : event.getVariable("score")[chr.getId()]]);
            ls = ls.sort(descend);
        }
    } else {
        for (let i = 0; i < members.length; i++) {
            ls.push([members[i].getId(), 0]);
            event.getVariable("score")[members[i].getId()] = 0;
            event.getVariable("range")[members[i].getId()] = 0;
        }
    }

    event.getMap(EVENT_FIELD).updateFieldRank(20, ls);
}

function spawnDrop() {
    let dropCount = 10;
    event.getMap(EVENT_FIELD).clearDrops();
    let droped = [];
    let dropPos = mapType == 0 ? item_pos_1 : item_pos_2;
    for (let i = 0; i < dropCount; i++) {
        let itemId = Math.floor(Math.random() * 4) + 2023295;
        let pos = dropPos[Math.floor(Math.random() * dropPos.length)]; 
        while (droped.indexOf(pos[0]) > 0) {//防止重叠
            pos = dropPos[Math.floor(Math.random() * dropPos.length)];
        }
        event.getMap(EVENT_FIELD).spawnItemDrop(itemId, 1, pos[0], pos[1], false, true);
        droped.push(pos[0]);
    }
    broadcastEventNotice(-1, "道具已经生成。");
}

function broadcastEventNotice(type, msg) {
    for (let i = 0; i < members.length; i++) {
        members[i].dropMessage(type, msg);
    }
}

function deinit() {
    for (let i = 0; i < members.length; i++) {
        members[i].changeMap(EXIT_MAP);
    }
}

function descend(x,y){
    return y[1] - x[1];  //按照数组的第4个值升序排列
}