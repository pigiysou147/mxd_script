/**
 * Demian
 */

let event = npc.getEvent("boss_demian_hard");
if (event != null && event.getVariable("boss2") == null) {
        event.setVariable("boss2", false);
        let boss = map.makeMob(8880101);
        boss.changeBaseHp(1065000000000);
        map.spawnMob(boss, 828, 15);
        map.startDemianFieldEvent(2, 8880101);
}