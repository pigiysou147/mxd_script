let eventName;
let bossId;
let eyeId;
let spieId;
let hp;

switch (map.getId()) {
    case 450008950: //normal
        bossId = 8880342;
        spieId = 8880354;
        eyeId = 8880358;
        hp = 10500000000000;
        eventName = "boss_will"
        break;
    case 450008350:
        bossId = 8880302;
        spieId = 8880324;
        eyeId = 8880328;
        hp = 52500000000000;
        eventName = "boss_will_hard"
        break;
}

let event = npc.getEvent(eventName);
if (event != null && event.getVariable("boss3") == null) {
    event.setVariable("boss3", false);
    let boss = map.makeMob(bossId);
    boss.changeBaseHp(hp);
    map.spawnMob(boss, -85, 150);

    let spie = map.makeMob(spieId);
    map.spawnMob(spie, -85, 150);

    let eye = map.makeMob(eyeId);
    map.spawnMob(eye, -85, 150);
    map.setWillBoss(boss, null, null);
}