
/**
 * Demian
 */

let event = npc.getEvent("boss_demian_hard");
if (event != null && event.getVariable("boss1") == null) {
        event.setVariable("boss1", false);
        let boss = map.makeMob(8880100);
        boss.changeBaseHp(24850000000000);
        map.spawnMob(boss, 828, 15);
        map.startDemianFieldEvent(1, 8880100);
}