let eventName;
let bossId;
let eyeId;
let spieId;
let hp;

switch (map.getId()) {
    case 450008850: //normal
        bossId = 8880341;
        spieId = 8880353;
        eyeId = 8880357;
        hp = 6300000000000;
        eventName = "boss_will"
        break;
    case 450008250:
        bossId = 8880301;
        spieId = 8880323;
        eyeId = 8880327;
        hp = 31500000000000;
        eventName = "boss_will_hard"
        break;
}

let event = npc.getEvent(eventName);
if (event != null && event.getVariable("boss2") == null) {
    event.setVariable("boss2", false);
    let boss = map.makeMob(bossId);
    boss.changeBaseHp(hp);
    boss.setHpLimitPercent(1 / 2);
    map.spawnMob(boss, 352, 150);

    let spie = map.makeMob(spieId);
    map.spawnMob(spie, 352, 150);

    let eye = map.makeMob(eyeId);
    map.spawnMob(eye, 352, 150);

    let peras = [500, 3];
    map.setWillBoss(boss, null, null);
    map.showWillHpBar(peras);
}