/**
 * Demian
 */

let event = npc.getEvent("boss_demian");
if (event != null && event.getVariable("boss1") == null) {
        event.setVariable("boss1", false);
        let boss = map.makeMob(8880110);
        boss.changeBaseHp(840000000000);
        map.spawnMob(boss, 828, 15);
        map.startDemianFieldEvent(1, 8880110);
}