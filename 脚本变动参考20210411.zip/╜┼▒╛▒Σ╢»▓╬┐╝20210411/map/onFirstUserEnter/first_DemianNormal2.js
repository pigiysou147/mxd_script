/**
 * Demian
 */

let event = npc.getEvent("boss_demian");
if (event != null && event.getVariable("boss2") == null) {
        event.setVariable("boss2", false);
		let boss = map.makeMob(8880111);
        boss.changeBaseHp(360000000000);
        map.spawnMob(boss, 828, 15);
        map.startDemianFieldEvent(2, 8880111);
}