let event = npc.getEvent("boss_will");
if (event == null) {
    event = npc.getEvent("boss_will_hard");
}
if (event != null && event.getVariable("boss1") != null) {
    let peras = [666, 333, 3];
    map.showWillHpBar(peras);
}