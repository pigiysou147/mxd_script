/*  This is mada by Yanran    
 *
 *  功能：[消亡旅途]火焰鸟
 *
 *  @Author Yanran
 */

let selection = npc.askYesNo("移动到#r安息洞穴 - 洞穴入口#k？", 3003136);
if (selection == 1) {
        player.changeMap(450001200, 2);
}