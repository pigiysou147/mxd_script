﻿
player.loseItem(2022529);
 player.runScript("装备评分更新");