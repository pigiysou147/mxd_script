
var z = "#fUI/UIWindow/Quest/icon5/1#"; //"+z+"//美化
var vvv4 = "#fEffect/CharacterEff/1112926/0/0#"; //红星
var z1 =  "#fUI/GuildMark/Mark/Etc/00009020/1#"; //星系
var tz14 = "#fEffect/CharacterEff/1112926/0/0#"; //红星
var xp = "#fEffect/BasicEff/MainNotice/BlockBuster/Default/3#";
var tz12 = "#fEffect/CharacterEff/1112924/0/0#"; //黄星
var tz13 = "#fEffect/CharacterEff/1112925/0/0#"; //蓝星
var tz14 = "#fEffect/CharacterEff/1112926/0/0#"; //红星
var aaa = "#fUI/UIWindow4/PQRank/rank/gold#";


var list = Array(
	Array("活跃奖励", 9310073, "huoyue"),
	Array("在线奖励", 9310073, "zxjl"),
	Array("每日寻宝", 2084001, "每日寻宝"),
	Array("每日跑环", 2470018, "mrph"),
	
	Array("突破任务", 9310073, "tprw"),
	Array("组队任务", 9310073, "zuduirenwu"),
	Array("沙漠跑商", 9310073, "跑商入口"),
	Array("骰子大师", 9310073, "dicemaster_start"),
	Array("突破极限", 9310073, "突破副本"),
	Array("绯红组队", 9310073, "突破副本"),
	Array("每日航海", 9310073, "突破副本"),
	Array("金币副本", 9310073, "金币副本入口")
	

);

		var text = "\t\t\t\t#e#r" + xp + "[任务发布榜]" + xp + "\r\n\r\n"
		for(var i = 0; i < list.length; i++) {
			text += "#r#e#L" + i + "#" + z1 + list[i][0] + "#l#d#e";
			if(i == 2 || i == 5 || i == 8) {
				text += "\r\n\r\n";
			} else {
				text += "\t"
			}
		}
		let selection =npc.askMenu(text,9270081);
		if(selection == 4) {
			player.changeMap(102000005);
		}else if(selection==7){
			
			player.changeMap(867121900);
		}else if(selection==9){
			
			player.changeMap(610030020);
		}else if(selection==10){
			
			if(!player.isQuestCompleted(17007)){
				player.startQuest(17003,0);
				player.changeMap(865010200);
			}else{
				player.changeMap(865000001);
			}
		} else {
			player.runScript( list[selection][2]);
		}

	
