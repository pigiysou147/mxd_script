/*  This is mada by Yanran    
 *  
 *  [拉克兰]--禁止通行
 *  
 *  @Author Yanran
 */


npc.sayNextS("现在不是有其他事情吗？");
