/* This is mada by Care

 * 玛瑙戒指 类型 组合

 * global cm

 * 脚本定制 技术支持 游戏顾问 423283141
*/

var Icon = Array(
	Array("星星", "#fEtc/ChatEmoticon/expression/1/0#"),
	Array("兔子", "#fEffect/CharacterEff/1112960/0/1#"),
	Array("星空", "#fUI/GuildMark/BackGround/00001013/16#"),
	Array("骷髅", "#fUI/GuildMark/Mark/Etc/00009000/15#"),
	Array("红心", "#fUI/GuildMark/Mark/Etc/00009001/1#"),
	Array("白脸", "#fUI/GuildMark/Mark/Etc/00009002/4#"),
	Array("皇冠", "#fUI/GuildMark/Mark/Etc/00009004/3#"),
	Array("红灯", "#fUI/GuildMark/Mark/Etc/00009020/1#"),
	Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/11#"),
	Array("水滴", "#fEffect/BasicEff/MainNotice/Gamsper/Notify/4#"),
	Array("红旗", "#fEffect/BasicEff/MainNotice/BlockBuster/Default/3#"),
	Array("红心", "#fEffect/CharacterEff/1112905/0/0#"),
	Array("云朵", "#fEffect/ItemEff/1102877/effect/default/1#"),
	Array("翅膀", "#fEffect/ItemEff/1102874/effect/ladder/0#"),
	Array("箭矢", "#fEffect/ItemEff/1112003/0/2#"),
	Array("黄鸭", "#fEffect/ItemEff/1004122/effect/default/8#"),
	Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/10#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/2#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/3#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/4#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/5#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/6#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/7#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/8#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/9#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/10#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/11#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/12#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/13#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/14#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/15#"),
	Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/16#"),
	Array("条件", "#fUI/UIWindow2.img/Quest/quest_info/summary_icon/startcondition#"),
	Array("信封", "#fUI/GuildMark/BackGround/00001003/5#"),
	Array("信封", "#fUI/GuildMark/BackGround/00001003/12#"),
	Array("钻石", "#fUI/NameTag/medal/556/w#"),
	Array("钻石", "#fUI/NameTag/medal/556/c#"),
	Array("钻石", "#fUI/NameTag/medal/556/e#"),
	Array("三角", "#fUI/piggyBarMinigame/crunch/5#"),
	Array("蓝点", "#fUI/piggyBarMinigame/crunch/1#"),
	Array("女神", "#fUI/RunnerGame/RunnerGameUI/Effect/ItemEffect_Protect1/3#"),
	Array("拇指", "#fUI/NameTag/medal/10/w#"),
	Array("拇指", "#fUI/NameTag/medal/10/c#"),
	Array("拇指", "#fUI/NameTag/medal/10/e#"),
	Array("成功", "#fUI/UIWindowJP/inputDirectionBattleTrigger/input/0/dear/7#"),
	Array("失败", "#fUI/UIWindowJP/inputDirectionBattleTrigger/input/0/fail/7#"),
	Array("星星", "#fUI/UIWindowGL/FeedbackSystem/Star#"),
	Array("蓝星", "#fEffect/CharacterEff/1003393/1/0#"),
	Array("花朵", "#fEffect/CharacterEff/1050334/2/0#"),
	Array("蓝星", "#fEffect/CharacterEff/1003393/0/0#"),
	Array("淡星", "#fEffect/CharacterEff/moveRandomSprayEff/eunwol_seal/effect/0/2#"),
	Array("花朵", "#fEffect/CharacterEff/1051294/1/0#"),
	Array("花朵", "#fEffect/CharacterEff/1051296/1/0#"),
	Array("金菇", "#fUI/NameTag/medal/74/w#"),
	Array("金菇", "#fUI/NameTag/medal/74/c#"),
	Array("金菇", "#fUI/NameTag/medal/74/e#"),
	Array("蛋糕", "#fUI/NameTag/medal/758/w#"),
	Array("蛋糕", "#fUI/NameTag/medal/758/c#"),
	Array("蛋糕", "#fUI/NameTag/medal/758/e#"),
	Array("鬍子", "#fUI/NameTag/124/w#"),
	Array("鬍子", "#fUI/NameTag/124/c#"),
	Array("鬍子", "#fUI/NameTag/124/e#"),
	Array("帽子", "#fUI/NameTag/nick/312/w#"),
	Array("帽子", "#fUI/NameTag/nick/312/c#"),
	Array("帽子", "#fUI/NameTag/nick/312/e#"),
	Array("圣诞", "#fUI/NameTag/medal/728/w#"),
	Array("圣诞", "#fUI/NameTag/medal/728/c#"),
	Array("圣诞", "#fUI/NameTag/medal/728/e#"),
	Array("红钻", "#fUI/UIWindowPL/DuoEvent/Maximum/DuoInfo/icon/GoodF/0#"),
	Array("王冠", "#fUI/NameTag/medal/468/w#"),
	Array("王冠", "#fUI/NameTag/medal/468/c#"),
	Array("王冠", "#fUI/NameTag/medal/468/e#"),
	Array("确认", "#fUI/CashShop.img/CSCoupon/BtOK/normal/0#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/ladder/0#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/7#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/walk1/3#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/jump/0#"),
	Array("音符", "#fEffect/ItemEff/1112811/0/0#"),
	Array("十字", "#fUI/GuildMark/Mark/Pattern/00004002/1#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/0#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/1#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/2#"),
	Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/3#"),
	Array("彩虹", "#fEffect/ItemEff/1102877/effect/default/0#"),
	Array("开始", "#fUI/UIWindow2.img/Quest/quest_info/summary_icon/startcondition#"),
	Array("猫咪", "#fUI/NameTag/190/w#"),
	Array("猫咪", "#fUI/NameTag/190/c#"),
	Array("猫咪", "#fUI/NameTag/190/e#"),
	Array("蝗虫", "#fUI/NameTag/188/w#"),
	Array("蝗虫", "#fUI/NameTag/188/c#"),
	Array("蝗虫", "#fUI/NameTag/188/e#"),
	Array("数值", "#fUI/Basic/LevelNo/1#"),
	Array("数值", "#fUI/Basic/LevelNo/2#"),
	Array("数值", "#fUI/Basic/LevelNo/3#"),
	Array("数值", "#fUI/Basic/LevelNo/4#"),
	Array("女孩", "#fEffect/CharacterEff.img/MeisterEff/Alchemy/11#"),
	Array("三角符", "#fUI/StatusBar.img/base/iconMemo#"),
	Array("锤子", "#fEffect/CharacterEff.img/MeisterEff/Equipment/10#"),
	Array("冰川", "#fEffect/CharacterEff.img/swimEff_large/back/0#"),
	Array("麦格纳斯", "#fUI/UIMiniGame.img/startPlanetYutGame/Piece/2/1P/catch/3#"),
	Array("麦格纳斯", "#fUI/UIMiniGame.img/startPlanetYutGame/Piece/2/2P/catch/5#"),
	Array("标志", "#fEffect/CharacterEff.img/WaterSmashClassEff/Cygnus/3/2#")
);

var GDP=0;
var txt="";

var Break = [
	[100, 6000000, 10000000], /* 余额 */
]
var Equip = player.getInventorySlot(-1, -11);

if(Equip == null) {
	player.dropAlertNotice("你并没有携带任何武器");
} else {
	txt = "\r\n";
	txt += "\t\t" + Icon[99][1] + " #r#e破攻中心 #k#n\r\n\r\n";
	txt += "　#L1#" + Icon[96][1] + "　#r[ 余额 ] 类型 #d当前破攻值 :#b" + Equip.getLimitBreak() + "#l\r\n";

	let selection=npc.askMenuS(txt);

	GDP = selection;

	/* 余额类型 */
	txt = "\r\n\t\t\t　" + Icon[96][1] + " #r余额破攻类型 " + Icon[96][1] + "#k\r\n\r\n";
	txt += " " + Icon[96][1] + " #d当前图鉴 : #b#i" + Equip.getDataId() + "##k\r\n";
	txt += " " + Icon[96][1] + " #d当前信息 : #b#z" + Equip.getDataId() + "##k\r\n";
	txt += " " + Icon[96][1] + " #d当前余额 : #r" + getHyPay(1) + "#k\r\n";
	txt += " " + Icon[96][1] + " #d允许破攻 : #r" + parseInt(getHyPay(1) / Break[0][0]) + " #b回#k\r\n";
	txt += " " + Icon[96][1] + " #d当前破攻 : #b" + Equip.getLimitBreak() + "#k\r\n\r\n";
	txt += " " + Icon[96][1] + " #d每回 #r" + Break[0][0] + "#d 余额 提升 #b" + Break[0][1] + "#d - #b" + Break[0][2] + " 随机值#k\r\n\r\n";
	txt += "\t\t\t\t#e#r请输入你想破攻多少回 ? #k#n\r\n\r\n ";
	let number=npc.askNumber(txt, 1, 1, parseInt(getHyPay() / Break[0][0]));
	
	
	var Random_value = 0;
	var Random = 0;
	txt = "\t\t\t　" + Icon[96][1] + " #r破攻信息显示 " + Icon[96][1] + "#k\r\n\r\n";
	for(var i = 0; i < number; i++) {
		Random = RandomNumBoth(Break[0][1], Break[0][2]);
		Random_value += Random;
		txt += " " + Icon[96][1] + " #d第 " + (i+1) + " 回 破攻值 :#r" + Random + "#k\r\n";
	}
	Equip.setLimitBreak(Equip.getLimitBreak() + Random_value);

	addHyPay(Break[0][0] * number);

	player.updateItem(-11,Equip);

	txt += "\r\n#b\t总提升值 :#r" + Random_value + "#k\t#b当前值 :#r" + Equip.getLimitBreak();
	npc.say(txt);
}


function RandomNumBoth(Min, Max) {
	var Range = Max - Min;
	var Rand = Math.random();
	var num = Min + Math.round(Rand * Range);
	return num;
}

function FormatString(c, length, content) { //符号 位置 代码 - 文本类型 .toString()
	var str = "";
	var cs = "";
	if(content.length > length) {
		str = content;
	} else {
		for(var j = 0; j < length - content.getBytes("GB2312").length; j++) {
			cs = cs + c;
		}
	}
	str = content + cs;
	return str;
}

function getHyPay() {
	var sql = "select pay from hypay where accountId = ? ";
	var result = player.customSqlResult(sql, player.getAccountId());
	return result.get(0).get("pay");
}

function addHyPay(price) {
	var sql = "update hypay set pay=pay-?,payused=payused+"+price+" where accountId=?";
	var result = player.customSqlUpdate(sql, price, player.getAccountId());

}