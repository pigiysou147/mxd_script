/**
* 自选脸型-新端脚本修改 几里 315342975 
**/

var item = 5152053; //所需物品

let res;
let isAngel = false;
let isBeta = false;
if (player.getBeginner() == 6001) {
    isAngel = npc.askAngelicBuster() != 0;
} else if (player.getBeginner() == 10000) {
    isBeta = npc.askMenu("请选择：\r\n#b#L0#神之子：阿尔法#l\r\n#L1#神之子：贝塔#l") != 0;
}
let selection = npc.askMenu("您好，请选择你需要的服务。\r\n查询脸型网站：stringwz.766wy.cn\r\n#b#L0#自选脸型,自己填脸型代码（使用#v"+item+"#）");
switch (selection) {
    case 0:
		let number = npc.askNumber("请填写脸型代码（请再三确认过后再填写！）","20000",20000,29999);
        faces = [number];
        res = npc.askAvatar("我能把你现在的脸型变成全新的脸型。你对现在的脸型不厌倦吗?只要你有#b#t5150052##k,我就帮你换脸型。慢慢挑选你想要的脸型吧~", faces, item, isAngel, isBeta);
        break;
}
selection = res[0];
let buy = res[1];

if (player.hasItem(item, 1)) {
    player.loseItem(item, 1);
    player.setFace(faces[selection]);
    npc.sayNext("完成了,享受你的新脸型吧!");
}else {
    npc.sayNext("呃……你好像没有#v"+item+"#啊？很抱歉，没有#v"+item+"#的话，我不能给你做头发。");
}