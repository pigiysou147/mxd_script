
/**
 * 副本: 无限火力
 * @author 
 */

let mobId = 9101078;

let fightTime = 10 * 60 * 1000;//每一轮时间
let MAP_ID = 867202398;
let EXIT_MAP=224000000;
let level = 1;
let map;
let bossHp=100000000000;
let endTime;
let start;
let end;
let totalTime=0;
let BOSS_LOG="团队火焰狼";
let DEATH_COUNT=5;
var tupoTotal=0;
let members;
function init(attachment) {

        [party,tupoTotal] = attachment;
		
		start=new Date().getTime();
        event.getMap(MAP_ID).clearMobs();
        party.changeMap(MAP_ID, 0);
		members=party.getLocalMembers();
        map = event.getMap(MAP_ID);
		//召唤BOSS
		//计算血量：突破值总数X 基础倍数
		bossHp=tupoTotal*bossHp;
		let mob = map.makeMob(mobId);
		mob.changeBaseHp(bossHp);
		mob.setForcedMobStat(275,10000);
		map.spawnMob(mob, -363, -65);

		
		
        event.startTimer("makeMob", 10*1000);
        event.startTimer("kick", fightTime);
		map.showTimer(fightTime/1000);

		for (let i = 0; i < members.length; i++) {
			members[i].setEvent(event);
			members[i].addPQLog(BOSS_LOG);
			members[i].setDeathCount(DEATH_COUNT);
			//判断伤害初始化 20191017
			event.setVariable(members[i].getName()+"伤害",0);
	}
}

function mobDied(mob) {
    if(mobId==mob.getDataId()){
		//通关

		//停止倒计时踢出
		event.stopTimer ("kick");
		//30秒后踢出
        event.startTimer("kick", 30*1000);
		map.showTimer(30);
		
		removePlayer(player.getId(), false);
		
	}
}



//记录伤害 20191017
function mobHit(player, mob, damage) {
	if(mobId==mob.getDataId()){
		var playerAllDamage = parseFloat(event.getVariable(player.getName()+"伤害"));
		event.setVariable(player.getName()+"伤害",(playerAllDamage+damage))
		player.dropMessage(1,"玩家："+player.getName()+" 目前伤害为:"+Math.floor((playerAllDamage+damage)/100000000)+" E");
	}
}

function removePlayer(playerId, changeMap) {
	player.setEvent(null);     
	
	event.destroyEvent();
	player.changeMap(224000000);
}

function playerDisconnected(player) {
        removePlayer(player.getId());
}

function playerChangedMap(player,destination) { 
	if(destination.getId() != MAP_ID){
		removePlayer(player.getId());
	}
}

function partyMemberDischarged(party, player) {
	removePlayer(player.getId());
}

function timerExpired(key) {
        switch (key) {
			case "kick":

				for (let i = 0; i < members.length; i++) {
					//dissociate event before changing map so playerChangedMap is not
					//called and this method is not called again by the player
					members[i].setEvent(null);
					members[i].changeMap(EXIT_MAP);
				}
				event.destroyEvent();
				break;
			
        }
}


function deinit() {
        player.setEvent(null);
		player.setDeathCount(-1);
}
