/*
 * NeroMS MapleStory server emulator written in Java
 * Copyright (C) 2017-2018  Jackson
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *
 * @author Jackson
 */


let frequency = 60 * 1000;//泡点间隔 单位毫秒
let mapList = [224000000]; //泡点运作的地图

var pdnum = 20;//普通泡点数量
let points = {//泡点奖励列表。
    vip: {//每个VIP等级判断的物品
        普通: [2430865, 1],
        尊贵会员: [2430865, 1]
    },
    reward: {//每个VIP等级的奖励
        普通: [ // VIP等级，必须有VIP0
            [1, 20, 20, "点券"],
            [1, 20, 20, "抵用券"]
        ],
        尊贵会员: [
            [1, 40, 40, "点券"],
            [1, 20, 20, "抵用券"]
        ]
    }
}

function init(attachment) {
	event.setVariable("hour", 20);
	event.setVariable("min", 30);
    event.startTimer("point", frequency);
}

function timerExpired(key) {
    switch (key) {
        case "point":
			
            let players = event.getChannelPlayers();
			for (let i = 0; i < players.size(); i++) {
				let player = players.get(i);
                if(player.getChannel()==1){
                    player.dropMessage(1,"进入泡点");
				    player.runScript("泡点奖励T");
                }
				
			}
			
            event.startTimer("point", frequency);
            break;
    }
}

