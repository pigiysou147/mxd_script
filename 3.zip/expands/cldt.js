var status = 0;
var ttt = "#fUI/UIWindow/Quest/icon2/7#"; //"+ttt+"//美化1
var ttt2 = "#fUI/UIWindow/Quest/icon6/7#"; ////美化2
var ttt3 = "#fUI/UIWindow/Quest/icon3/6#"; //"+ttt3+"//美化圆
var ttt4 = "#fUI/UIWindow/Quest/icon5/1#"; //"+ttt4+"//美化New
var ttt5 = "#fUI/UIWindow/Quest/icon0#"; ////美化!
var ttt7 = "#fUI/Basic/BtHide3/mouseOver/0#"; //"+ttt6+"//美化会员
var ttt6 = "#fUI/UIWindow.img/PvP/Scroll/enabled/next2#";
var epp = "#fEffect/CharacterEff/1082312/0/0#"; //彩光
var eff = "#fCharacter/Weapon/01702523.img/48/straight/0/effect#"; //彩虹带
var eff1 = "#fEffect/CharacterEff/1112905/0/1#"; //
var epp2 = "#fEffect/CharacterEff/1082312/0/0#"; //彩光
var epp1 = "#fEffect/CharacterEff/1082312/2/0#"; //彩光1
var axx = "#fEffect/CharacterEff/1051294/0/0#"; //爱心
var xxx = "#fEffect/CharacterEff/1082565/2/0#"; //星系
var ppp = "#fEffect/CharacterEff/1112907/4/0#"; //泡炮 
var epp3 = "#fEffect/CharacterEff/1112908/0/1#"; //彩光3
var axx1 = "#fEffect/CharacterEff/1062114/1/0#"; //爱心
var zs = "#fEffect/CharacterEff/1112946/2/0#"; //砖石粉
var zs1 = "#fEffect/CharacterEff/1112946/1/1#"; //砖石蓝
var dxxx = "#fEffect/CharacterEff/1102232/2/0#"; //星系
var tz = "#fEffect/CharacterEff/1082565/2/0#"; //兔子蓝
var tz1 = "#fEffect/CharacterEff/1082565/4/0#"; //兔子粉
var tz7 = "#fEffect/CharacterEff/1112900/3/1#"; //音符红
var tz8 = "#fEffect/CharacterEff/1112900/4/1#"; //音符绿
var tz88 = "#fEffect/CharacterEff/1112900/5/1#"; //音符绿!
var yun1 = "#fUI/UIWindow/Quest/icon7/10#"; ////红色圆
var tz9 = "#fEffect/CharacterEff/1112902/0/0#"; //蓝心
var tz10 = "#fEffect/CharacterEff/1112903/0/0#"; //红心
var tz11 = "#fEffect/CharacterEff/1112904/0/0#"; //彩心
var tz12 = "#fEffect/CharacterEff/1112924/0/0#"; //黄星
var tz13 = "#fEffect/CharacterEff/1112925/0/0#"; //蓝星
var tz14 = "#fEffect/CharacterEff/1112926/0/0#"; //红星
var tz15 = "#fEffect/CharacterEff/1112949/0/0#"; //花样音符
var tz16 = "#fEffect/CharacterEff/1112949/1/0#"; //花样音符
var tz17 = "#fEffect/CharacterEff/1112949/2/0#"; //花样音符
var tz18 = "#fEffect/CharacterEff/1112949/3/0#"; //花样音符
var tz19 = "#fEffect/CharacterEff/1112949/4/0#"; //花样音符
var tz20 = "#fEffect/CharacterEff/1114000/1/0#"; //红星花
var wn11 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/0#"; //黑
var wn12 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/1#"; //红
var wn13 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/2#"; //橙
var wn14 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/3#"; //黄
var wn15 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/4#"; //绿
var wn16 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/5#"; //亲
var wn17 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/6#"; //紫
var wn18 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/7#"; //褐
var p2 = "#fUI/StatusBar2.img/starPlanet/achive/1#";
var p1 = "#fUI/SoulUI.img/DungeonMap/icon/dungeonItem/0#";
var q = "#fUI/UIPVP.img/MiniMapIcon/star#"
var pk1 = "#fUI/UIWindow.img/createCygnus/BtLeft/mouseOver/0#";
var pk2 = "#fUI/UIWindow.img/createCygnus/BtRight/normal/0#";
var pk3 = "#fUI/UIWindowBT.img/WorldMap/QuestList/resultQuest/icon#"
var ttt = "#fUI/UIWindowBT/WorldMap/BtNext/normal/0# ";
var ttt1 = "#fMap/MapHelper.img/mark/CrossHunter#";
var ltz41 = "#fMap/MapHelper.img/weather/starPlanet2/2#"; //小的蓝色天使翅膀
var ttt2 = "#fMap/MapHelper.img/mark/MushroomVillage#"; //
var ttt3 = "#fMap/MapHelper.img/minimap/partymaster#"; //橙色点
var ttt4 = "#fMap/MapHelper.img/weather/6th/12#"; //紫色星球
var ttt5 = "#fMap/MapHelper.img/weather/2011Haloween/1#"; //糖果

var selStr = "          #e#d" + ttt4 + " 材料地图中心 " + ttt4 + "#n#k\r\n";
selStr += "\r\n#L77##b" + ttt5 + " [地图]战甲吹泡泡鱼#r（可爆内存卡）#l\r\n";
selStr += "#L1##b" + ttt5 + " [地图]红色枫叶/换极品卷轴#r（危险，新手不要去）\r\n";
selStr += "#L3##b" + ttt5 + " [地图]力量智慧敏捷幸运母矿系列#r（140装备需要！！！）\r\n";
selStr += "#L2##b" + ttt5 + " [地图]漂漂猪海岸#r（可获得 猪头，动物皮）\r\n";
selStr += "#L5##b" + ttt5 + " [地图]时间异常之地#r（可获得 绿帽海贼的发动机,物品结晶）\r\n";
selStr += "#L10##b" + ttt5 + " [地图]灼热峡谷#r（可获得 变形的尖牙,运动会币）\r\n";
selStr += "#L6##b" + ttt5 + " [地图]苔藓树丛西部森林2#r（可获得 青苔石，征服者币）\r\n";
selStr += "#L7##b" + ttt5 + " [地图]研究所202号#r（可获得 5月露水）\r\n";
selStr += "#L8##b" + ttt5 + " [地图]初级修炼场#r（可获得 稻草玩偶）\r\n\r\n\r\n\r\n";
let selection=npc.askMenuS(selStr);
switch(selection) {
	case 1:
		player.changeMap(273010000);
		break;
	case 1:
		player.changeMap(273010000);
		break;
	case 2:
		player.changeMap(102030000);
		break;
	case 3:
		player.changeMap(310040400);
		break;
	case 77:
		player.changeMap(221020701);
		break;
	case 4:
		player.runScript(9310060);
		break;
	case 5:
		player.changeMap(220060201);
		break;
	case 6: //兑换中心
		player.changeMap(300010200);
		break;
	case 7: //兑换中心
		player.changeMap(261010102);
		break;
	case 8: //
		player.changeMap(250020000);
		break;
	case 9: //崎岖荒野
		
		player.changeMap(273060100);
		break;
	case 10: //分解装备
		player.changeMap(273030000);
		break;
}