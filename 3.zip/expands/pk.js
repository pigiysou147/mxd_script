var stard = Array(
	3060000, 3060001, 3060010, 3060011, 3060020, 3060021, 3060030, 3060031, 3060040, 3060041, 3060042, 3060050, 3060051, 3060052, 3060060, 3060061, 3060070, 3060071, 3060080, 3060081, 3060090, 3060091, 3060100, 3060110, 3060120, 3060121, 3060122, 3060130, 3060131, 3060132, 3060140, 3060150, 3060160, 3060170, 3060180
)
var starc = Array(
	3061000, 3061001, 3061010, 3061011, 3061020, 3061021, 3061030, 3061031, 3061040, 3061041, 3061042, 3061050, 3061051, 3061052, 3061060, 3061061, 3061070, 3061071, 3061080, 3061081, 3061090, 3061091, 3061100, 3061110, 3061120, 3061121, 3061122, 3061123, 3061124, 3061125, 3061130, 3061131, 3061132, 3061133, 3061134, 3061135, 3061140, 3061150, 3061160, 3061170, 3061180, 3061190, 3061200, 3061210, 3061220, 3061230, 3061240, 3061250, 3061260, 3061270, 3061271, 3061280, 3061290, 3061291, 3061292, 3061293, 3061294, 3061295, 3061300, 3061301, 3061302, 3061303, 3061304, 3061305, 3061310, 3061311, 3061312, 3061313, 3061314, 3061315, 3061320, 3061321, 3061322, 3061323, 3061324, 3061325, 3061330, 3061331, 3061332, 3061333, 3061334, 3061335, 3061340, 3061341, 3061350, 3061351, 3061360, 3061361, 3061362, 3061370, 3061371, 3061380, 3061381, 3061390
)

var starb = Array(
	3062000, 3062001, 3062010, 3062011, 3062020, 3062021, 3062030, 3062031, 3062040, 3062041, 3062042, 3062050, 3062051, 3062052, 3062060, 3062061, 3062062, 3062070, 3062071, 3062072, 3062080, 3062081, 3062090, 3062091, 3062100, 3062101, 3062102, 3062103, 3062110, 3062111, 3062112, 3062113, 3062120, 3062121, 3062122, 3062130, 3062131, 3062132, 3062140, 3062150, 3062160, 3062170, 3062180, 3062190, 3062200, 3062210, 3062220, 3062230, 3062240, 3062250, 3062260, 3062261, 3062270, 3062271, 3062280, 3062281, 3062290, 3062291, 3062292, 3062293, 3062294, 3062295, 3062300, 3062301, 3062302, 3062303, 3062304, 3062305, 3062310, 3062320, 3062321, 3062322, 3062323, 3062324, 3062325, 3062330, 3062331, 3062332, 3062333, 3062334, 3062335, 3062340, 3062341, 3062342, 3062343, 3062344, 3062345, 3062350, 3062360, 3062370, 3062371, 3062372, 3062373, 3062374, 3062375, 3062380, 3062381, 3062382, 3062383, 3062384, 3062385
)

var stara = Array(
	3063000, 3063001, 3063010, 3063011, 3063020, 3063021, 3063030, 3063031, 3063040, 3063041, 3063042, 3063050, 3063051, 3063052, 3063060, 3063061, 3063062, 3063063, 3063070, 3063071, 3063072, 3063073, 3063080, 3063081, 3063090, 3063091, 3063100, 3063101, 3063102, 3063103, 3063110, 3063111, 3063112, 3063113, 3063120, 3063121, 3063122, 3063130, 3063131, 3063132, 3063140, 3063141, 3063150, 3063151, 3063160, 3063161, 3063170, 3063171, 3063180, 3063181, 3063190, 3063191, 3063200, 3063201, 3063210, 3063211, 3063220, 3063221, 3063230, 3063231, 3063240, 3063241, 3063250, 3063251, 3063260, 3063261, 3063270, 3063271, 3063280, 3063281, 3063290, 3063300, 3063310, 3063320, 3063330, 3063340, 3063341, 3063350, 3063351, 3063360, 3063361, 3063370, 3063380, 3063390, 3063400
)

var stars = Array(
	3064000, 3064001, 3064002, 3064010, 3064011, 3064012, 3064020, 3064021, 3064022, 3064030, 3064031, 3064032, 3064040, 3064041, 3064042, 3064050, 3064051, 3064052, 3064060, 3064061, 3064062, 3064070, 3064071, 3064072, 3064080, 3064081, 3064090, 3064091, 3064100, 3064101, 3064110, 3064111, 3064120, 3064121, 3064122, 3064123, 3064124, 3064130, 3064131, 3064132, 3064133, 3064134, 3064140, 3064141, 3064150, 3064151, 3064160, 3064161, 3064170, 3064171, 3064180, 3064181, 3064190, 3064191, 3064200, 3064201, 3064210, 3064211, 3064220, 3064221, 3064230, 3064231, 3064240, 3064241, 3064250, 3064251, 3064260, 3064261, 3064270, 3064271, 3064272, 3064280, 3064281, 3064282, 3064290, 3064291, 3064300, 3064301, 3064302, 3064310, 3064311, 3064320, 3064330, 3064331, 3064340, 3064341, 3064350, 3064360, 3064370, 3064380, 3064390, 3064391, 3064392, 3064393, 3064400, 3064401, 3064410, 3064420, 3064421, 3064430, 3064431, 3064440, 3064441, 3064442, 3064450, 3064451, 3064452, 3064460, 3064461, 3064470, 3064480, 3064490
)
var 勋章 = "#fCharacter/Accessory/01143012.img/info/icon#"
var g = "#fEffect/CharacterEff/1082565/0/0#"; //饼干兔子
var tz20 = "#fEffect/CharacterEff/1114000/1/0#"; //红星花
var tz7 = "#fEffect/CharacterEff/1112949/1/0#"; //好看1
var tz8 = "#fEffect/CharacterEff/1112949/2/0#"; //好看1
var tz88 = "#fEffect/CharacterEff/1112949/3/0#"; //好看1



var potList = Array(
	Array(-1, "帽子", 0),
	Array(-2, "前额", 0),
	Array(-3, "脸饰", 0),
	Array(-4, "耳饰", 0),
	Array(-5, "衣服", 0),
	Array(-6, "短裤", 0),
	Array(-7, "鞋子", 0),
	Array(-8, "手套", 0),
	Array(-9, "披风", 0),
	Array(-29, "腰带", 0),
	Array(-30, "肩部", 0),
	Array(-37, "符号", 0),
	Array(-36, "徽章", 0),
	Array(-26, "奖牌", 0),
	Array(-17, "吊坠", 1),
	Array(-38, "吊坠", 2),
	Array(-10, "副手", 0),
	Array(-11, "武器", 0),
	Array(-12, "戒指", 1),
	Array(-13, "戒指", 2),
	Array(-15, "戒指", 3),
	Array(-16, "戒指", 4),
	Array(-27, "戒指", 5),
	Array(-28, "戒指", 6),
	Array(-33, "口袋", 0),
	Array(-34, "机器", 0),
	Array(-35, "心脏", 0),
	Array(-5000, "图腾", 1),
	Array(-5001, "图腾", 2),
	Array(-5002, "图腾", 3),
	Array(-1600, "神秘", 1),
	Array(-1601, "神秘", 2),
	Array(-1602, "神秘", 3),
	Array(-1603, "神秘", 4),
	Array(-1604, "神秘", 5),
	Array(-1605, "神秘", 6)
);
var potList1 = Array(
	Array(-1, "帽子", 0),
	Array(-2, "前额", 0),
	Array(-3, "脸饰", 0),
	Array(-4, "耳饰", 0),
	Array(-5, "衣服", 0),
	Array(-6, "短裤", 0),
	Array(-7, "鞋子", 0),
	Array(-8, "手套", 0),
	Array(-9, "披风", 0),
	Array(-29, "腰带", 0),
	Array(-30, "肩部", 0),
	Array(-37, "符号", 0),
	Array(-36, "徽章", 0),
	Array(-26, "奖牌", 0),
	Array(-17, "吊坠1", 1),
	Array(-38, "吊坠2", 2),
	Array(-10, "副手", 0),
	Array(-11, "武器", 0),
	Array(-12, "戒指1", 1),
	Array(-13, "戒指2", 2),
	Array(-15, "戒指3", 3),
	Array(-16, "戒指4", 4),
	Array(-27, "戒指5", 5),
	Array(-28, "戒指6", 6),
	Array(-33, "口袋", 0),
	Array(-34, "机器", 0),
	Array(-35, "心脏", 0),
	Array(-5000, "图腾1", 1),
	Array(-5001, "图腾2", 2),
	Array(-5002, "图腾3", 3),
	Array(-1600, "神秘1", 1),
	Array(-1601, "神秘2", 2),
	Array(-1602, "神秘3", 3),
	Array(-1603, "神秘4", 4),
	Array(-1604, "神秘5", 5),
	Array(-1605, "神秘6", 6)
);



//装备检测评分

var totalScore = 0;
var Single = 0;
var text = "";
var myScore=[];
var targetScore=[];
var compare=0;
var sql = "insert into zz_totalscore value ( " + player.getId() + ",'" + player.getName() + "','" + jobType4(player.getJob()) + "',0 ";
var item;
var itemStr;
for(var i = 0; i < potList.length; i++) {
	item = player.getInventorySlot(-1, potList[i][0]);
	Single = scoreAll(item, potList[i][0]);
	myScore[i]=Single;
	if(item != null) {
		sql += "," + Single + "," + item.getOnlyId();
	} else {
		sql += "," + Single + "," + 0;
	}

	totalScore += Single;
}
sql += "," + totalScore + " ) ";
var stats = player.customSqlResult("select * from challengerstats where characterid="+player.getId());
if(stats.size()==0){
	//增加一条记录再查询
	player.customSqlInsert("insert into challengerstats (characterid) values(?)",player.getId());
	stats = player.customSqlResult("select * from challengerstats where characterid="+player.getId());
}
var myStats=[
	["力量",0,4440001],
	["敏捷",0,4441001],
	["智力",0,4442001],
	["运气",0,4443001],
	["攻击",0,4021030]
	];
myStats[0][1]=stats.get(0).get("str");
myStats[1][1]=stats.get(0).get("dex");
myStats[2][1]=stats.get(0).get("int");
myStats[3][1]=stats.get(0).get("luk");
myStats[4][1]=stats.get(0).get("pad");
var statsScore=0;
statsScore+=myStats[0][1];
statsScore+=myStats[1][1];
statsScore+=myStats[2][1];
statsScore+=myStats[3][1];
statsScore+=myStats[4][1];
statsScore=statsScore*1;

text +="#r#L997##v4031569#查看对战记录#l\t#L996##v4031569#增加能力值#l\r\n";
text += "#L998##v4031569#自己选择对手作战#l#L999##v4031569#系统分配对手作战#l\r\n\r\n";

//删榜 再  写榜 
totalLog(sql);
var score=player.customSqlResult("select score from characters where id = "+player.getId()).get(0).get("score");
totalScore+=statsScore;

var dsScore=0;

var jfLevel = [ 	
[1000,"新手"],	
[2000,"冒险家"],	
[3000,"战士"],	
[4000,"勇士"],	
[5000,"英雄"],	
[6000,"龙骑士"],	
[7000,"战神"],	
[8000,"傲世战神"],	
[10000,"巅峰王者"]

];
var myLevel=1;
//识别会员等级操作
for(var i=0;i<jfLevel.length;i++){
	if(score>=jfLevel[i][0]){
		myLevel++;
	}else{
		break;
	}
}
var rwr="#e#r#r#e#L1235#【当前对战总得分为:"+score+"】<点击查看积分排行榜>#k\r\n#L1234##v1143234#当前称谓为:"+jfLevel[myLevel-1][1]+" <领取称谓奖励>#l\r\n";

rwr+="\r\n#v4032220#总功力值为：" + (statsScore) + " " 
rwr +="#b\r\n#b#v"+myStats[0][2]+"#"+myStats[0][0]+myStats[0][1]+"\t#v"+myStats[1][2]+"#"+myStats[1][0]+myStats[1][1]+"\t#v"+myStats[2][2]+"#"+myStats[2][0]+myStats[2][1]+"\r\n#v"+myStats[3][2]+"#"+myStats[3][0]+myStats[3][1]+" #v"+myStats[4][2]+"#"+myStats[4][0]+myStats[4][1]+"\r\n";
rwr+=text;

var selected = npc.askMenu(rwr); //sort+ numberString
if(selected < 900) {
	npc.sayNext(equipmentPosition(selected, player.getId())); //装备部位评分
} else if(selected == 998) {
	chooseCharacters(); //装备评分排行榜
} else if(selected == 1235) {
	player.runScript("pk排行榜");
	
	
	
	
	
} else if(selected == 1234) {
	player.runScript("称谓奖励"); //装备评分排行榜
} else if(selected == 999) {
	getRandom(); //职业评分排行榜
} else if(selected == 997) {
	npc.say(getRecords()); //装备部位评分
} else if(selected == 996) {
	var needItem=[
		[
			[4440300,1],
			[4440200,4],
			[4440101,15],
			[4440001,60],
		],
		[
			[4443300,1],
			[4443200,4],
			[4443101,15],
			[4443001,60]
		],
		[
			[4442300,1],
			[4442200,4],
			[4442101,15],
			[4442001,60]
		],
		[
			[4441300,1],
			[4441200,4],
			[4441101,15],
			[4441001,60]
		],
		[
			[4021030,1],
			[4021030,1],
			[4021030,1],
			[4021030,1]
		],
	];
	//选取材料增加自己的能力值
	var txt="#r#e请选择要增加的能力.\r\n";
	txt+="#L0##v4440001#增加力量#l\r\n";
	txt+="#L1##v4443001#增加敏捷#l\r\n";
	txt+="#L2##v4442001#增加智力#l\r\n";
	txt+="#L3##v4441001#增加运气#l\r\n";
	txt+="#L4##v4021030#增加攻击#l\r\n";
	var attrPos=npc.askMenu(txt);
	txt="#r#e请选择要消耗的材料\r\n\r\n";
	
	//没完成突破。。
	//增加材料消耗;
	//单独消耗突破材料分支
	
	var statusValues=[20000,50000,100000,180000];	
	var tupoList=[
		
		4009457,
		4009459,
		4009456,
		4009454,
		4009455
	];
	var jdNeed=[
		300,
		800,
		2000,
		5000
	];
	
	
	
	for(var i=0;i<statusValues.length;i++){
		txt+="阶段 : "+statusValues[i]+" 需求材料 #v"+tupoList[attrPos]+"# X "+jdNeed[i]+"\r\n";
	}
	for(var i=0;i<needItem[attrPos].length;i++){
		
		txt+="#L"+i+"#兑换比例 #v"+needItem[attrPos][i][0]+"# X  1 可以兑换能力值 "+needItem[attrPos][i][1]+"点#l\r\n";
	}
	var baoshi=npc.askMenu(txt);
	var needId= needItem[attrPos][baoshi][0];
	var bili =needItem[attrPos][baoshi][1];
	
	
	var number =npc.askNumber("#r#e请输入要消耗的#v"+needId+"#的数量",1,1,player.getAmountOfItem(needId));
	
	var yes = npc.askYesNo("#r#e是否确认使用#v"+needId+"# X "+number+" 来兑换 "+(number*bili)+"  能力值");
	
	if(yes==1){
		//判定阶段性突破是否完成。
		
		var limit =0;
		var jieduan=0;
		var energyName=myStats[attrPos][0];
		var energy =myStats[attrPos][1];
		for(var i=0;i<statusValues.length;i++){
			if(energy<statusValues[i]){
				limit=statusValues[i];
				jieduan=i;
				break;
			}
		}
		energy =myStats[attrPos][1]+number*bili;
		
		var tupoCoast=jdNeed[jieduan];
		var tupoItem=tupoList[attrPos];
		//npc.say("jieduan :"+jieduan+"阶段是否突破："+player.getPQLog(energyName+"阶段:"+limit)+" limit "+ limit+"  tupoCoast "+tupoCoast+"  tupoItem"+tupoItem);
		//做一下跳级处理
		var next=0;
		
		//npc.say("next："+next+" energy "+energy);
		//需要识别
		//判定当前阶段是否已经突破过了；
		if(player.getPQLog(energyName+"阶段:"+limit)> 0 || energy<limit || limit ==0){
				var next=0;
				if(jieduan==4 || energy>=280000 || myStats[attrPos][1]>=180000){
					next=280000;
				}else{
					next=statusValues[jieduan+1];
				}
				if(energy>next){
					
					if(energy>=280000){
						npc.say("最大能力值不允许超过280000");
					}else{
						npc.say("#r#e不能跳级，你需要先突破下一等级:"+next);
					}
					
				}else{
					//已经完成突破;
					//或者是0阶段
					//npc.say("当前能力值选择的是: "+energyName+" 当前本身能力值为:"+energy+"  目前区间为: "+limit);
					
					//确认兑换
					player.loseItem(needId,number);
					//判断属性来增加
					if(attrPos==0){
						//力量
						player.customSqlUpdate("update challengerstats set str=str+"+(number*bili)+" where characterid="+player.getId());
					}else if(attrPos==1){
						//敏捷
						player.customSqlUpdate("update challengerstats set dex=dex+"+(number*bili)+" where characterid="+player.getId());
					}else if(attrPos==2){
						//智力
						player.customSqlUpdate("update challengerstats set `int`=`int`+"+(number*bili)+" where characterid="+player.getId());
					}else if(attrPos==3){
						//运气
						player.customSqlUpdate("update challengerstats set luk=luk+"+(number*bili)+" where characterid="+player.getId());
					}else if(attrPos==4){
						//攻击
						player.customSqlUpdate("update challengerstats set pad=pad+"+(number*bili)+" where characterid="+player.getId());
					}
					npc.say("兑换完成");
				}
				
				
			
			
			
		}else{
			
			
			let sel =npc.askYesNo("#r#e你需要#v"+tupoItem+"# X " +tupoCoast +"来突破当前阶段 \r\n是否要突破？");
			if(sel==1){
				if(player.hasItem(tupoItem,tupoCoast)){
					//可以突破
					player.loseItem(tupoItem,tupoCoast);
					player.addPQLog(energyName+"阶段:"+limit,1,999);
					npc.say("突破成功");
				}else{
					npc.say("材料不足，无法突破");
				}
			}
		}
	
		
	}
	
	
	
	
}

function getRecords(){
	var resultList = player.customSqlResult("select *,DATE(time) ti from challenger_records where challengerid ="+player.getId()+" order by ti desc");
	var tt="\t\t\t\t\t#r#e对战记录\r\n\r\n";
	if(resultList.size()>0){
		
		tt+="\t对局结果\t\t\t时间\t\t\t  玩家\r\n\r\n";
		for(var i=0;i<resultList.size();i++){
			tt+="   #r";
			
			tt+=resultList.get(i).get("ti").toString()+"";
			
			tt+="\t\t#b"
			
			if(resultList.get(i).get("score")>0){
				tt+="#r获胜+"+resultList.get(i).get("score")+"#k";
			}else if(resultList.get(i).get("score")<0){
				tt+="#g失败-"+resultList.get(i).get("score")*-1+"#k";
			}else{
				tt+="#b平局#k";
			}
			var number=resultList.get(i).get("score");
			if(number>0){
				number=number*-1
			}
			var length1=1;
			while (number > 0) {
				number = number / 10;
				length1++;
			}
			for(var j=0;j<8-length1;j++){
				tt+=" " ;
			}
			
			
			tt+=resultList.get(i).get("opponentname");
			
			tt+="\r\n";
		}
	}else{
		tt+="暂无对战记录"
	}
	return tt;
}

      
function getRandom(){
	var characterid = getRanDomId();
	dsScore=player.customSqlResult("select score from characters where id = "+characterid).get(0).get("score");

	//查找出对应的人物                                                                                                                       
	var selected = npc.askMenu(characterEquipInfo(characterid));
	if(selected==999){
		score=player.customSqlResult("select score from characters where id = "+player.getId()).get(0).get("score");
		compare=0;
		getRandom();
	}else{
		npc.sayNext(equipmentPosition(selected, characterid)); //装备部位评分	
	}
	
}

function getRanDomId(){
	//查出评分表
	var sql ="SELECT * from (select pf.`name`,pf.characterid,pf.jobname,pf.worldid,`总评分`,ch.score from zz_totalscore as pf,characters as ch where pf.characterid=ch.id and  ch.score<="+score+" and ch.id<>"+player.getId()+" ORDER BY score limit 100) as a ORDER BY RAND() limit 5";

	
	var resultList = player.customSqlResult(sql);

	sql ="SELECT * from (select pf.`name`,pf.characterid,pf.jobname,pf.worldid,`总评分`,ch.score from zz_totalscore as pf,characters as ch where pf.characterid=ch.id and  ch.score>"+score+" and ch.id<>"+player.getId()+" ORDER BY score limit 100) as a ORDER BY RAND() limit 5";

	var resultList1 = player.customSqlResult(sql);


	resultList.addAll(resultList1);
	//npc.say(resultList);
	return resultList.get(Math.random()*resultList.size()).get("characterid");
}
	  
function chooseCharacters() {
	var characterid = npc.askMenu(equipmentRankingText());
	dsScore=player.customSqlResult("select score from characters where id = "+characterid).get(0).get("score");

	//查找出对应的人物                                                                                                                       
	var selected = npc.askMenu(characterEquipInfo(characterid));
	
	npc.sayNext(equipmentPosition(selected, characterid)); //装备部位评分	

}
function equipmentRankingText() {
	//查出评分表
	var sql ="SELECT * from (select pf.`name`,pf.characterid,pf.jobname,pf.worldid,`总评分`,ch.score from zz_totalscore as pf,characters as ch where pf.characterid=ch.id and  ch.score<="+score+" and ch.id<>"+player.getId()+" ORDER BY score limit 5) as a ORDER BY RAND() limit 5";

	
	var resultList = player.customSqlResult(sql);

	sql ="SELECT * from (select pf.`name`,pf.characterid,pf.jobname,pf.worldid,`总评分`,ch.score from zz_totalscore as pf,characters as ch where pf.characterid=ch.id and  ch.score>"+score+" and ch.id<>"+player.getId()+" ORDER BY score limit 5) as a ORDER BY RAND() limit 5";

	var resultList1 = player.customSqlResult(sql);


	resultList.addAll(resultList1);
	for(var i=0;i<resultList.size();i++){
		for(var j=i+1;j<resultList.size();j++){
			if(resultList.get(i).get("characterid")==resultList.get(j).get("characterid")){
				resultList.remove(j);
			}
		}
	}

	var text = "    #fs18##e" + 勋章 + " #r回忆岛 / #b对手列表#k " + 勋章 + "#fs12#\r\n\r\n";
	text += "       积分       玩家名字       评分\r\n";
	for(var i = 0; i < resultList.size(); i++) {
		var result = resultList.get(i);
		if(result == null) {
			break;
		}
		text += "\t#L" + result.get("characterid") + "# " + nbsp10(result.get("score")) + "" + nbsp10(result.get("name")) + "     #r" + result.get("总评分") + "#k#l\r\n";
		
	}
	return text;
}
//根据人物ID查询出人物评分信息                                                                                                               
function characterEquipInfo(characterid) {
	var sql = "select * from zz_totalscore where characterid = " + characterid;
	var resultList = player.customSqlResult(sql);
	var text = "";
	for(var i = 0; i < resultList.size(); i++) {
		var result = resultList.get(i);
		if(result == null) {
			break;
		}
		if(selected==999){
			text+="#r#e\r\n#L999#直接进行下一局#l\r\n\r\n";
		}
		text += "#e对手:[#r" + result.get("name") + "#k]：积分总分：#r" + dsScore + "#k\r\n";
		text +="自身:[#b" + player.getName() + "#k]：积分总分：#b" + score + "#k\r\n";
		/*
		if(totalScore>parseInt(result.get("总评分"))){
			text+="#r总分胜利+2分#k";
			compare+=2;
		}else if(totalScore<parseInt(result.get("总评分"))){
			text+="#g总分失败-2分#k";
			compare-=2;
		}else{
			text+="#b总分平局+0分#k";
			
		}
		*/
		
		var ttt="\r\n\r\n";
		ttt+="\t#r#e部位\t\t\t战果    \t对手评分 VS 自身评分\r\n";
		//增加四维对比
		ttt+=compareStats(result.get("characterid"));
		for(var i=0;i<potList1.length;i++){
			targetScore[i]=result.get(potList1[i][1]);
			ttt += writeText(potList1[i][1], result)+"\r\n";
		}
		
		
		//在这里判断自己和对手的分差;
		//如果自己遥遥领先，那就缩减自己获得的分数，对手就不扣分
		//如果自己落后很多
		var chaju = score-dsScore;
		var add=compare;
		var jianshao=compare;
		text+="";
		if(compare>0){
			text+="#r对局获胜比分"+(compare);
			//更新自己的分数和对手的分数
			//判断一下分数的差值
			if(chaju>=0){
				//领先
				if(chaju>=1000 && chaju<2000){
					compare=parseInt(compare/2);
				}else if(chaju>=2000){
					compare=0;
				}
			}else{
				//落后
				chaju=chaju*-1;
				if(chaju>=1000 && chaju<2000){
					compare=parseInt(compare*2);
				}else if(chaju>=2000){
					compare=parseInt(compare*2*parseInt(chaju/1000));
				}
			}
			//增加自己的分数
			player.customSqlUpdate("update characters set score=score+"+compare+" where id = "+player.getId());
			//扣对方的分数
			player.customSqlUpdate("update characters set score=score-"+(compare/10)+" where id = "+result.get("characterid"));
			
			
		}else if(compare==0){
			text+="#b平局";
			//不处理
		}else{
			text+="#g对局失败比分"+(compare);
			//扣自己的分数，给对面加分数
			if(chaju>=0){
				//领先
				if(chaju>=1000 && chaju<2000){
					compare=parseInt(compare*2);
				}else if(chaju>=2000){
					compare=0;
				}
			}else{
				//落后
				chaju=chaju*-1;
				if(chaju>=1000 && chaju<2000){
					compare=parseInt(compare/2);
				}else if(chaju>=2000){
					compare=0;
				}
			}
			//扣自己的分数
			player.customSqlUpdate("update characters set score=score+"+compare+" where id = "+player.getId());
			//增加对方的分数
			player.customSqlUpdate("update characters set score=score-"+(compare/10)+" where id = "+result.get("characterid"));
			
		}
		player.customSqlInsert("insert into challenger_records values(0,?,?,?,?,?,now())",player.getId(),player.getName(),result.get("characterid"),result.get("name"),add);
		player.customSqlInsert("insert into challenger_records values(0,?,?,?,?,?,now())",result.get("characterid"),result.get("name"),player.getId(),player.getName(),add/10);
		text+="\t\t#r#e最后分数为:"+compare+" ";
		text+=ttt;
	}
	return text;
}

function compareStats(id){
	var duishou=[
	["力量",0],
	["敏捷",0],
	["智力",0],
	["运气",0],
	["攻击",0]
	];
	var resultList=player.customSqlResult("select * from challengerstats where characterid="+id);
	if(resultList.size()>0){
		//装填属性
		duishou[0][1]=resultList.get(0).get("str");
		duishou[1][1]=resultList.get(0).get("dex");
		duishou[2][1]=resultList.get(0).get("int");
		duishou[3][1]=resultList.get(0).get("luk");
		duishou[4][1]=resultList.get(0).get("pad");
	}
	//进行各项对比
	var re="#n";
	for(var i=0;i<duishou.length;i++){
		re+="\t #k#b" + duishou[i][0] + "#k";
		
		re+="    ";
		if(myStats[i][1]>duishou[i][1]){
			re+="#r\t胜利+1分#k";
			compare+=1;
		}else if(myStats[i][1]==duishou[i][1]){
			re+="#b\t平局+0分#k";
			
		}else{
			re+="#g\t失败-1分#k";
			compare-=1;
		}
		var number=duishou[i][1];
		var length1=1;
		while (number > 0) {
			number = number / 10;
			length1++;
		}
		for(var j=0;j<12-length1;j++){
			re+=" " ;
		}
		re+=" #r" + duishou[i][1] + "#b#r:"+myStats[i][1]+"" ;
		
		re+="\r\n";
	}
	return re;
}

function writeText(title, result) {
	var pos = 0;
	var index=0;
	for(var i = 0; i < potList.length; i++) {
		if(potList[i][2] != 0) {
			if((potList[i][1] + potList[i][2]) == title) {
				pos = Math.abs(potList[i][0]);
				index=i;
			}
		} else {
			if(potList[i][1] == title) {
				pos = Math.abs(potList[i][0]);
				index=i;
			}
		}
		
		
	}
	var re =  "#L" + pos + "##k#n#b  " + title.toString().substr(0, 2) + "#k";
	
	re+="   ";
	if(result.get(title)<myScore[index]){
		re+="#r\t 胜利+1分#k";
		compare+=1;
	}else if(result.get(title)==myScore[index]){
		re+="#b\t 平局+0分#k";
		
	}else{
		re+="#g\t 失败-1分#k";
		compare-=1;
	}
	
	
	for(var j=0;j<12-result.get(title).toString().length;j++){
		re+=" " ;
	}
		
	
	re+=" #r" + result.get(title) + "#b#r:"+myScore[index]+"" ;
	
	
	re+="#l";
	//re+= nbspLen(result.get(title), 6) + " ";
	
	return re;

}


//装备部位评分
function equipmentPosition(selected, characterid) {
	var pos = "id";
	for(var i = 0; i < potList.length; i++) {
		if(Math.abs(potList[i][0]) == selected) {
			if(potList[i][2] == 0) {
				pos += potList[i][1];
			} else {
				pos += potList[i][1] + potList[i][2];
			}
		}
	}
	var text = "";
	var sql = "select * from zz_inventoryitems_equip where id = (select	 " + pos + " from zz_totalscore  where characterid = " + characterid + ")";
	
	var resultList = player.customSqlResult(sql);
	for(var i = 0; i < resultList.size(); i++) {
		var result = resultList.get(i);
		if(result == null) {
			break;
		}
		text += "id:" + result.get("id") + "#v" + result.get("itemid") + "##z" + result.get("itemid") + "#\r\n";
		text += "#e#b力量:" + nbspStrAdd(result.get("str"), 5);
		text += "\t敏捷:" + nbspStrAdd(result.get("dex"), 5);
		text += "\r\n运气:" + nbspStrAdd(result.get("luk"), 5);
		text += "\t智力:" + nbspStrAdd(result.get("int"), 5);
		text += "\r\n#k最大血量:" + nbspStrAdd(result.get("maxhp"), 5);
		text += "\r\n最大魔量:" + nbspStrAdd(result.get("maxmp"), 5);
		text += "\r\n#r攻击力:" + nbspStrAdd(result.get("pad"), 5);
		text += "\r\n魔法力:" + nbspStrAdd(result.get("mad"), 5);
		text += "\r\n#k防御力:" + nbspStrAdd(result.get("pdd"), 5);
		text += "\r\n可升级次数:" + nbspStrAdd(result.get("nRUC"), 5);
		text += "\r\n已强化次数:" + nbspStrAdd(result.get("nCUC"), 5);
		text += "\r\n星之力:" + nbspStrAdd(result.get("nCHUC"), 5);
		text += "\r\n强化:" + nbspStrAdd(result.get("title"), 5);
		text += "\r\n神秘之力:" + nbspStrAdd(result.get("arc"), 5);
		text += "\r\n潜能1:" + getOptionName(nbspStrAdd(result.get("option1"), 5));
		text += "\r\n潜能2:" + getOptionName(nbspStrAdd(result.get("option2"), 5));
		text += "\r\n潜能3:" + getOptionName(nbspStrAdd(result.get("option3"), 5));
		text += "\r\n潜能4:" + getOptionName(nbspStrAdd(result.get("option4"), 5));
		text += "\r\n潜能5:" + getOptionName(nbspStrAdd(result.get("option5"), 5));
		text += "\r\n潜能6:" + getOptionName(nbspStrAdd(result.get("option6"), 5));

		if(pos == "id武器") {
			text += "\r\n#r突破值:" + nbspStrAdd(result.get("limitBreak"), 5) / 100000000 + " 亿\r\n";
		}
	}
	if(text == "") {
		text = "没有查到对应数据.";
	}
	return text;
}


function totalLog(sql) {
	
	
	

}

function addTotalScore(sql) {
player.customSqlInsert(sql);
}

function delTotalScore() {
var sql = " delete from zz_totalscore where characterid =  " + player.getId() + "  ";
player.customSqlUpdate(sql);
}

function numberString(number) {
return numberConvert(number) + nbsp(number);
}

function chkstrlen(str) {　
var strlen = 0;　
for(var i = 0; i < str.length; i++) {　
	if(str.charCodeAt(i) > 255) //如果是汉字，则字符串长度加2
		　　 strlen += 2;　　
	else　　　　 strlen++;　
}　
return strlen;
}

function nbsp10(str) {
var str = str + "";
var nbspStr = "";
if(chkstrlen(str) < 10) {
	for(var i = 0; i < 10 - chkstrlen(str); i++) {
		nbspStr += " ";
	}
}

return str + nbspStr;
}

function nbspStrAdd(str, len) {
var str = str + "";
var nbspStr = "";
if(chkstrlen(str) < len) {
	for(var i = 0; i < len - chkstrlen(str); i++) {
		nbspStr += " ";
	}
}

return str + nbspStr;
}

function nbspLen(number, len) {
var numberStr = number + "";
var numLength = chkstrlen(numberStr);
var nbspStr = "";
if(numLength < len) {
	for(var i = 0; i < len - numLength; i++) {
		nbspStr += " ";
	}
}
return nbspStr;
}

function nbsp(number) {
var numberStr = number + "";
var numLength = chkstrlen(numberStr);
var nbspStr = "";
if(numLength < 6) {
	for(var i = 0; i < 6 - numLength; i++) {
		nbspStr += " ";
	}
}
return nbspStr;
}

function numberConvert(number) {
var numberStr = number.toString();
var str = "";
for(var i = 0; i < numberStr.length; i++) {
	str += numberStr.substr(i, 1);
}
return str;
}

function icon(number) {
//return "#fUI/UIWindow8/restaurantREDmini/stackNo/"+number+"#";
//return "#fUI/UITemporarySkillBar/TemporarySkillBar/KeyDraw/"+number+"#";
//return "#fUI/UIWindowString/Scenario/quest_info/clear/number/"+number+"#";
return "#fUI/UIWindow4/TimeEvent/Number/" + number + "#";
}

function getOptionName(poid){
if(poid==0){
	return "无";
}
var potList = Array(
	Array(40603, "40%BOSS伤害", 1),
	Array(40051, "12%攻击力", 1),
	Array(60002, "20%所有属性", 1),
	Array(40052, "12%魔法攻击力", 1),
	Array(40055, "12%暴击率", 1),
	Array(60001, "12%伤害", 1),
	Array(60002,  "20%所有属性"), //
	Array(40051,  "12%攻击力"), //
	Array(40052,  "12%魔法攻击力"), //
	Array(40603,  "40%BOSS伤害"), //
	Array(40292,  "40%无视怪物防御力"), //
	Array(60059, "最大血量+20%", 2),
	Array(40041,  "12%力量"), //
	Array(40042,  "12%敏捷"), //
	Array(40043,  "12%智力"), //
	Array(40044,  "12%运气"), //
	Array(40045,  "12%maxHP"), //
	Array(40046,  "12%maxMp"), //
	Array(40047,  "12%命中率"), //
	Array(40056,  "8%暴击伤害"), //
	Array(40055,  "12%暴击率") //
);
var name ="普通潜能";
for(var i=0;i<potList.length;i++){
	if(potList[i][0]==poid){
		name=potList[i][1];
	}
}
return name;

}


//item.getItemID()
//1力量 2法师 3敏捷 4运气 6hp 7全属性
function getPotential(poten, item) {
	if(poten == 0) {
		return 0;
	}
	if(poten == 40070) { //伤害12%
		return 400;
	} else if(poten == 42051 || poten == 40051) { //攻击力
		if(jobType() == 2) {
			//法师型
			return 10;
		} else {
			if(getItemType(item.getDataId())) { //判断是否是武器或者副手
				return 500;
			} else {
				return 400;
			}
		}
	} else if(poten == 42052 || poten == 40052) { //魔法攻击
		if(jobType() != 2) {
			//不是法师型
			return 10;
		} else {
			if(getItemType(item.getDataId())) { //判断是否是武器或者副手
				return 500;
			} else {
				return 400;
			}
		}
	} else if(poten == 60005) { //40%无视防御
		return 500;
	} else if(poten == 40056) { //40%暴击伤害
		return 800;
	} else if(poten == 60001) { //40%暴击伤害
		return 500;
	} else if(poten == 40292) { //40%无视防御
		return 400;
	} else if(poten == 40291) { //35%无视防御
		return 350;
	} else if(poten == 30291) { //30%无视防御
		return 300;
	} else if(poten == 40601 || poten == 30602) { //30%boss伤害
		return 300;
	} else if(poten == 40602) { //35%boss伤害
		return 350;
	} else if(poten == 40603) { //40%boss伤害
		return 400;
	} else if(poten == 60059) { //20%血量
		return 500;
	} else if(poten == 42086) { //5%全属性
		return plus100_50(7);
	} else if(poten == 40086) { //9%全属性
		return plus200_150(7);
	} else if(poten == 30086) { //6%全属性
		return plus150_100(7);
	} else if(poten == 40045) { //12%hp
		return plus200(6);
	} else if(poten == 30045) { //9%hp
		return plus150(6);
	} else if(poten == 42091 || poten == 42041) { //10级力量+2  7%
		return plus100(1);
	} else if(poten == 42092 || poten == 42042) { //10级敏捷+2  7%
		return plus100(3);
	} else if(poten == 42093 || poten == 42043) { //10级智力+2  7%
		return plus100(2);
	} else if(poten == 42094 || poten == 42044) { //10级运气+2  7%
		return plus100(4);
	} else if(poten == 40041) { //力量12%
		return plus200(1);
	} else if(poten == 40042) { //敏捷12%
		return plus200(3);
	} else if(poten == 40043) { //智力12%
		return plus200(2);
	} else if(poten == 40044) { //运气12%
		return plus200(4);
	} else if(poten == 30041) { //力量9%
		return plus150(1);
	} else if(poten == 30042) { //敏捷9%
		return plus150(3);
	} else if(poten == 30043) { //智力9%
		return plus150(2);
	} else if(poten == 30044) { //运气9%
		return plus150(4);
	} else {
		return 10;
	}
}

function plus200(type) {
if(jobType() != type) {
	return 10;
} else {
	return 200;
}
}

function plus200_150(type) {
if(jobType() != type) {
	return 150;
} else {
	return 200;
}
}

function plus150(type) {
if(jobType() != type) {
	return 10;
} else {
	return 150;
}
}

function plus150_100(type) {
if(jobType() != type) {
	return 100;
} else {
	return 150;
}
}

function plus100(type) {
if(jobType() != type) {
	return 10;
} else {
	return 100;
}
}

function plus100_50(type) {
if(jobType() != type) {
	return 50;
} else {
	return 100;
}
}

function jobType() {

var jobs = Array(
	Array("炼狱黑客", 6300 , 3),
	Array("炼狱黑客", 6310 , 3),
	Array("炼狱黑客", 6311 , 3),
	Array("炼狱黑客", 6312 , 3),

	Array("拳天", 17500 , 3),
	Array("拳天", 17510 , 3),
	Array("拳天", 17511 , 3),
	Array("拳天", 17512 , 3),


	Array("御剑骑士", 15100 , 1),
	Array("御剑骑士", 15110 , 1),
	Array("御剑骑士", 15111 , 1),
	Array("御剑骑士", 15112 , 1),
	Array("战士", 100, 1),
	Array("剑客", 110, 1),
	Array("勇士", 111, 1),
	Array("英雄", 112, 1),
	Array("准骑士", 120, 1),
	Array("骑士", 121, 1),
	Array("圣骑士", 122, 1),
	Array("枪战士", 130, 1),
	Array("龙骑士", 131, 1),
	Array("黑骑士", 132, 1),
	Array("魔法师", 200, 2),
	Array("火毒法师", 210, 2),
	Array("火毒巫师", 211, 2),
	Array("火毒魔导", 212, 2),
	Array("冰雷法师", 220, 2),
	Array("冰雷巫师", 221, 2),
	Array("冰雷魔导", 222, 2),
	Array("牧师", 230, 2),
	Array("祭司", 231, 2),
	Array("主教", 232, 2),
	Array("弓箭手", 300, 3),
	Array("猎人", 310, 3),
	Array("射手", 311, 3),
	Array("神射手", 312, 3),
	Array("弩弓手", 320, 3),
	Array("游侠", 321, 3),
	Array("箭神", 322, 3),
	Array("飞侠", 400, 4),
	Array("刺客", 410, 4),
	Array("无影人", 411, 4),
	Array("隐士", 412, 4),
	Array("侠客", 420, 4),
	Array("独行客", 421, 4),
	Array("侠盗", 422, 4),
	Array("海盗", 500, 5),
	Array("拳手", 510, 1),
	Array("斗士", 511, 1),
	Array("冲锋队长", 512, 1),
	Array("火枪手", 520, 3),
	Array("大副", 521, 3),
	Array("船长", 522, 3),
	Array("魂骑士", 1100, 1),
	Array("魂骑士", 1110, 1),
	Array("魂骑士", 1111, 1),
	Array("魂骑士", 1112, 1),
	Array("炎术士", 1200, 2),
	Array("炎术士", 1210, 2),
	Array("炎术士", 1211, 2),
	Array("炎术士", 1212, 2),
	Array("风灵使者", 1300, 3),
	Array("风灵使者", 1310, 3),
	Array("风灵使者", 1311, 3),
	Array("风灵使者", 1312, 3),
	Array("夜行者", 1400, 4),
	Array("夜行者", 1410, 4),
	Array("夜行者", 1411, 4),
	Array("夜行者", 1412, 4),
	Array("袭者", 1500, 4),
	Array("袭者", 1510, 4),
	Array("袭者", 1511, 4),
	Array("袭者", 1512, 4),
	Array("战神", 2100, 1),
	Array("战神", 2110, 1),
	Array("战神", 2111, 1),
	Array("战神", 2112, 1),
	Array("炮手", 501, 1),
	Array("火炮手", 530, 1),
	Array("毁灭炮手", 531, 1),
	Array("神炮王", 532, 1),
	Array("双弩精灵", 2300, 3),
	Array("双弩精灵", 2310, 3),
	Array("双弩精灵", 2311, 3),
	Array("双弩精灵", 2312, 3),
	Array("幻影", 2400, 4),
	Array("幻影", 2410, 4),
	Array("幻影", 2411, 4),
	Array("幻影", 2412, 4),
	Array("夜光法师", 2700, 2),
	Array("夜光法师", 2710, 2),
	Array("夜光法师", 2711, 2),
	Array("夜光法师", 2712, 2),
	Array("恶魔猎手", 3100, 1),
	Array("恶魔猎手", 3110, 1),
	Array("恶魔猎手", 3111, 1),
	Array("恶魔猎手", 3112, 1),
	Array("恶魔复仇者", 3101, 6),
	Array("恶魔复仇者", 3120, 6),
	Array("恶魔复仇者", 3121, 6),
	Array("恶魔复仇者", 3122, 6),
	Array("唤灵法师", 3200, 1),
	Array("唤灵法师", 3210, 1),
	Array("唤灵法师", 3211, 1),
	Array("唤灵法师", 3212, 1),
	Array("豹弩游侠", 3300, 3),
	Array("豹弩游侠", 3310, 3),
	Array("豹弩游侠", 3311, 3),
	Array("豹弩游侠", 3312, 3),
	Array("机械师", 3500, 3),
	Array("机械师", 3510, 3),
	Array("机械师", 3511, 3),
	Array("机械师", 3512, 3),
	Array("爆破手", 3700, 1),
	Array("爆破手", 3710, 1),
	Array("爆破手", 3711, 1),
	Array("爆破手", 3712, 1),
	Array("尖兵", 3600, 7),
	Array("尖兵", 3610, 7),
	Array("尖兵", 3611, 7),
	Array("尖兵", 3612, 7),
	Array("米哈尔", 5100, 1),
	Array("米哈尔", 5110, 1),
	Array("米哈尔", 5111, 1),
	Array("米哈尔", 5112, 1),
	Array("狂龙战士", 6100, 1),
	Array("狂龙战士", 6110, 1),
	Array("狂龙战士", 6111, 1),
	Array("狂龙战士", 6112, 1),
	Array("爆莉萌天使", 6500, 2),
	Array("爆莉萌天使", 6510, 2),
	Array("爆莉萌天使", 6511, 2),
	Array("爆莉萌天使", 6512, 2),
	Array("龙的传人", 508, 3),
	Array("龙的传人", 570, 3),
	Array("龙的传人", 571, 3),
	Array("龙的传人", 572, 3),
	Array("隐月", 2500, 3),
	Array("隐月", 2510, 3),
	Array("隐月", 2511, 3),
	Array("隐月", 2512, 3),
	Array("剑豪", 4100, 1),
	Array("剑豪", 4110, 1),
	Array("剑豪", 4111, 1),
	Array("剑豪", 4112, 1),
	Array("阴阳师", 4200, 2),
	Array("阴阳师", 4210, 2),
	Array("阴阳师", 4211, 2),
	Array("阴阳师", 4212, 2),
	Array("超能力者", 14200, 2),
	Array("超能力者", 14210, 2),
	Array("超能力者", 14211, 2),
	Array("超能力者", 14212, 2),
	Array("龙神", 2210, 2),
	Array("龙神", 2212, 2),
	Array("龙神", 2216, 2),
	Array("龙神", 2217, 2),
	Array("双刀", 430, 4),
	Array("双刀", 431, 4),
	Array("双刀", 432, 4),
	Array("双刀", 433, 4),
	Array("双刀", 434, 4),
	Array("古代猎人", 301, 3),
	Array("古代猎人", 330, 3),
	Array("古代猎人", 331, 3),
	Array("古代猎人", 332, 3),
	Array("新手", 0, 1)
);

var myjob = player.getJob();
for(var i = 0; i < jobs.length; i++) {
	if(jobs[i][1] == myjob) {
		return jobs[i][2];
	}
}
return 1;
}

function jobType4(sel) {

var job4 = Array(
	Array("炼狱黑客", 6300 , 3),
	Array("炼狱黑客", 6310 , 3),
	Array("炼狱黑客", 6311 , 3),
	Array("炼狱黑客", 6312 , 3),

	Array("拳天", 17500 , 3),
	Array("拳天", 17510 , 3),
	Array("拳天", 17511 , 3),
	Array("拳天", 17512 , 3),


	Array("御剑骑士", 15100 , 1),
	Array("御剑骑士", 15110 , 1),
	Array("御剑骑士", 15111 , 1),
	Array("御剑骑士", 15112 , 1),
	Array("英雄", 112, 1),
	Array("圣骑士", 122, 1),
	Array("黑骑士", 132, 1),
	Array("火毒魔导士", 212, 2),
	Array("冰雷魔导士", 222, 2),
	Array("主教", 232, 2),
	Array("神射手", 312, 3),
	Array("箭神", 322, 3),
	Array("隐士", 412, 4),
	Array("侠盗", 422, 4),
	Array("冲锋队长", 512, 1),
	Array("船长", 522, 3),
	Array("魂骑士", 1112, 1),
	Array("炎术士", 1212, 2),
	Array("风灵使者", 1312, 3),
	Array("夜行者", 1412, 4),
	Array("袭者", 1512, 4),
	Array("战神", 2112, 1),
	Array("神炮王", 532, 1),
	Array("双弩精灵", 2312, 3),
	Array("幻影", 2412, 4),
	Array("夜光法师", 2712, 2),
	Array("恶魔猎手", 3112, 1),
	Array("恶魔复仇者", 3122, 6),
	Array("唤灵法师", 3212, 1),
	Array("豹弩游侠", 3312, 3),
	Array("机械师", 3512, 3),
	Array("爆破手", 3712, 1),
	Array("尖兵", 3612, 7),
	Array("米哈尔", 5112, 1),
	Array("狂龙战士", 6112, 1),
	Array("爆莉萌天使", 6512, 2),
	Array("龙的传人", 572, 3),
	Array("隐月", 2512, 3),
	Array("剑豪", 4112, 1),
	Array("阴阳师", 4212, 2),
	Array("超能力者", 14212, 2),
	Array("龙神", 2217, 2),
	Array("双刀", 434, 4),
	Array("古迹猎人", 332, 3),
	Array("新手", 0, 1)
);

var job = sel;

for(var i = 0; i < job4.length; i++) {
	if(job4[i][1] == job) {
		return job4[i][0];
	}
}
return "新手";
}

//获取装备类型
function getItemType(itemID) {
var type = Math.floor(itemID / 10000);
switch(type) {
	case 109:
		return true; //盾牌
	case 119:
		return true; //徽章
	case 118:
		return true; //徽章
	default:
		var type = Math.floor(type / 10);
		if(type == 12 || type == 13 || type == 14 || type == 15 || type == 17) {
			return true; //武器
		}
		return false;
}
}

function equip(itemID) {

var scoreEquip = Array(
	Array(1212120, 5000), //200武器
	Array(1222113, 5000), //
	Array(1232113, 5000), //
	Array(1242121, 5000), //
	Array(1242122, 5000), //
	Array(1252098, 5000), //
	Array(1262039, 5000), //
	Array(1302343, 5000), //
	Array(1312203, 5000), //
	Array(1322255, 5000), //
	Array(1332279, 5000), //
	Array(1342104, 5000), //
	Array(1362140, 5000), //
	Array(1372228, 5000), //
	Array(1382265, 5000), //
	Array(1402259, 5000), //
	Array(1412181, 5000), //
	Array(1422189, 5000), //
	Array(1432218, 5000), //
	Array(1442274, 5000), //
	Array(1452257, 5000), //
	Array(1462243, 5000), //
	Array(1472265, 5000), //
	Array(1482221, 5000), //
	Array(1492235, 5000), //
	Array(1522143, 5000), //
	Array(1532150, 5000), //
	Array(1542117, 5000), //
	Array(1552119, 5000), //
	Array(1582023, 5000), //
	Array(1152196, 2000), //200防具
	Array(1152197, 2000), //
	Array(1152198, 2000), //
	Array(1152199, 2000), //
	Array(1152200, 2000), //
	Array(1004808, 2000), //
	Array(1004809, 2000), //
	Array(1004810, 2000), //
	Array(1004811, 2000), //
	Array(1004812, 2000), //
	Array(1102940, 2000), //
	Array(1102941, 2000), //
	Array(1102942, 2000), //
	Array(1102943, 2000), //
	Array(1102944, 2000), //
	Array(1082695, 2000), //
	Array(1082696, 2000), //
	Array(1082697, 2000), //
	Array(1082698, 2000), //
	Array(1082699, 2000), //
	Array(1053063, 2000), //
	Array(1053064, 2000), //
	Array(1053065, 2000), //
	Array(1053066, 2000), //
	Array(1053067, 2000), //
	Array(1073158, 2000), //
	Array(1073159, 2000), //
	Array(1073160, 2000), //
	Array(1073161, 2000), //
	Array(1073162, 2000), //
	Array(1532098, 2500), //150武器
	Array(1522094, 2500), //
	Array(1492179, 2500), //
	Array(1482168, 2500), //
	Array(1472214, 2500), //
	Array(1462193, 2500), //
	Array(1452205, 2500), //
	Array(1442223, 2500), //
	Array(1432167, 2500), //
	Array(1422140, 2500), //
	Array(1412135, 2500), //
	Array(1402196, 2500), //
	Array(1382208, 2500), //
	Array(1372177, 2500), //
	Array(1362090, 2500), //
	Array(1342082, 2500), //
	Array(1332225, 2500), //
	Array(1322203, 2500), //
	Array(1312153, 2500), //
	Array(1302275, 2500), //
	Array(1242061, 2500), //
	Array(1242060, 2500), //
	Array(1232057, 2500), //
	Array(1222058, 2500), //
	Array(1212063, 2500), //
	Array(1003797, 1000), //150防具
	Array(1003798, 1000), //
	Array(1003799, 1000), //
	Array(1003800, 1000), //
	Array(1003801, 1000), //
	Array(1042254, 1000), //
	Array(1042255, 1000), //
	Array(1042256, 1000), //
	Array(1042257, 1000), //
	Array(1042258, 1000), //
	Array(1062165, 1000), //
	Array(1062166, 1000), //
	Array(1062167, 1000), //
	Array(1062168, 1000), //
	Array(1062169, 1000), //      
	Array(1212014, 1000), //140武器
	Array(1212101, 1000), //
	Array(1222014, 1000), //
	Array(1222095, 1000), //
	Array(1232014, 1000), //
	Array(1232095, 1000), //
	Array(1242014, 1000), //
	Array(1242042, 1000), //
	Array(1242102, 1000), //
	Array(1252014, 1000), //
	Array(1252086, 1000), //
	Array(1302152, 1000), //
	Array(1302315, 1000), //
	Array(1312065, 1000), //
	Array(1312185, 1000), //
	Array(1322096, 1000), //
	Array(1322236, 1000), //
	Array(1332130, 1000), //
	Array(1332260, 1000), //
	Array(1342036, 1000), //
	Array(1342095, 1000), //
	Array(1342100, 1000), //
	Array(1362019, 1000), //
	Array(1362121, 1000), //
	Array(1372084, 1000), //
	Array(1372207, 1000), //
	Array(1382104, 1000), //
	Array(1382245, 1000), //
	Array(1402095, 1000), //
	Array(1402236, 1000), //
	Array(1412065, 1000), //
	Array(1412164, 1000), //
	Array(1422066, 1000), //
	Array(1422171, 1000), //
	Array(1432086, 1000), //
	Array(1432200, 1000), //
	Array(1442116, 1000), //
	Array(1442254, 1000), //
	Array(1452111, 1000), //
	Array(1452238, 1000), //
	Array(1462099, 1000), //
	Array(1462225, 1000), //
	Array(1472122, 1000), //
	Array(1472247, 1000), //
	Array(1482084, 1000), //
	Array(1482202, 1000), //
	Array(1492085, 1000), //
	Array(1492212, 1000), //
	Array(1522018, 1000), //
	Array(1522124, 1000), //
	Array(1532018, 1000), //
	Array(1532130, 1000), //
	Array(1542015, 1000), //
	Array(1542101, 1000), //
	Array(1552015, 1000), //
	Array(1552102, 1000), //
	Array(1262015, 1000), //
	Array(1052314, 200), //140防具
	Array(1082295, 200), //
	Array(1152108, 200), //
	Array(1003172, 200), //
	Array(1072485, 200), //
	Array(1102275, 200), //
	Array(1052315, 200), //
	Array(1082296, 200), //
	Array(1152110, 200), //
	Array(1072486, 200), //
	Array(1003173, 200), //
	Array(1102276, 200), //
	Array(1052316, 200), //
	Array(1082297, 200), //
	Array(1152111, 200), //
	Array(1102277, 200), //
	Array(1003174, 200), //
	Array(1072487, 200), //
	Array(1052317, 200), //
	Array(1082298, 200), //
	Array(1152112, 200), //
	Array(1003175, 200), //
	Array(1102278, 200), //
	Array(1072488, 200), //
	Array(1052318, 200), //
	Array(1082299, 200), //
	Array(1152113, 200), //
	Array(1102279, 200), //
	Array(1003176, 200), //
	Array(1072489, 200), //
	Array(1032223, 2000), //最高级贝勒德
	Array(1122267, 2000), //
	Array(1132246, 2000), //
	Array(1113075, 2000), //
	Array(1672069, 1000), //女武神之心
	Array(1132174, 2000), //暴君
	Array(1132175, 2000), //
	Array(1132176, 2000), //
	Array(1132177, 2000), //
	Array(1132178, 2000), //
	Array(1102481, 2000), //
	Array(1102482, 2000), //
	Array(1102483, 2000), //
	Array(1102484, 2000), //
	Array(1102485, 2000), //
	Array(1082543, 2000), //
	Array(1082544, 2000), //
	Array(1082545, 2000), //
	Array(1082546, 2000), //
	Array(1082547, 2000), //
	Array(1072743, 2000), //
	Array(1072744, 2000), //
	Array(1072745, 2000), //
	Array(1072746, 2000), //
	Array(1072747, 2000) //
);

for(i = 0; i < scoreEquip.length; i++) {
	if(itemID == scoreEquip[i][0]) {
		return scoreEquip[i][1];
	}
}
return 100;
}

function Socket(Socket) {
for(var i = 0; i < stard.length; i++) {
	if(Socket == stard[i]) {
		return 50;
		break;
	}
}
for(var i = 0; i < starc.length; i++) {
	if(Socket == starc[i]) {
		return 100;
		break;
	}
}
for(var i = 0; i < starb.length; i++) {
	if(Socket == starb[i]) {
		return 150;
		break;
	}
}
for(var i = 0; i < stara.length; i++) {
	if(Socket == stara[i]) {
		return 200;
		break;
	}
}
for(var i = 0; i < stars.length; i++) {
	if(Socket == stars[i]) {
		return 500;
		break;
	}
}
return 0;

}

function addInventoryitemslog(id) {
//var sql = "insert into zz_inventoryitems_equip_log(select  *,now() from inventoryitems_equip where id = " + id + " )";
//player.customSqlInsert(sql);
}

function addInventoryitems(id) {
var sql = "insert into zz_inventoryitems_equip(select  * from inventory_equip where id = " + id + " )";

player.customSqlInsert(sql);
}

function delInventoryitems(id) {
var sql = " delete from zz_inventoryitems_equip where id =  " + id + "  ";
player.customSqlUpdate(sql);
}

function equipBak(id) {
//1天记录一次
if(player.getPQLog("每日记录装备流水") < 10 || true) {
	player.addPQLog("每日记录装备流水", 1, 1);
	//删除单件装备的信息
	delInventoryitems(id);
	//记录单件装备信息
	addInventoryitems(id);
	//记录到流水里
	addInventoryitemslog(id);
}
}

function scoreAll(item, postion) {

if(item != null) {
	//记录装备流水用于备份和排名

	equipBak(item.getOnlyId());
	//npc.say(item.toString().substr(item.toString().indexOf("EntId")+6,20)+"位置"+postion);
	var score = 0;
	score += getPotential(item.getOption(1, false), item);
	score += getPotential(item.getOption(2, false), item);
	score += getPotential(item.getOption(3, false), item);
	score += getPotential(item.getOption(1, true), item);
	score += getPotential(item.getOption(2, true), item);
	score += getPotential(item.getOption(3, true), item);
	if(item.getTotalStr() > 500) {
		score += 500;
	} else {
		score += item.getTotalStr() * 3;
	}

	if(item.getTotalDex() > 500) {
		score += 500;
	} else {
		score += item.getTotalDex() * 3;
	}

	if(item.getTotalInt() > 500) {
		score += 500;
	} else {
		score += item.getTotalInt() * 3;
	}

	if(item.getTotalLuk() > 500) {
		score += 500;
	} else {
		score += item.getTotalLuk() * 3;
	}

	if(item.getTotalPAD() > 1000) {
		score += 1000 * 20;
	} else {
		score += item.getTotalPAD() * 20;
	}

	if(item.getTotalMAD() > 1000) {
		score += 1000 * 20;
	} else {
		score += item.getTotalMAD() * 20;
	}
	if(item.getMaxHp()>=3000){
		
		score += 3000;
	}else{
		score += item.getMaxHp() * 1;
	}
	if(item.getMaxMp()>=3000){
		
		score += 3000;
	}else{
		score += item.getMaxMp() * 1;
	}
	score += item.getCraft() * 1; //手技
	score += item.getSpeed() * 1; //速度
	score += item.getJump() * 1; //跳跃
	score += item.getCUC() * 10; //升级次数
	score += item.getCHUC() * 20; //星星等级
	score += item.getGrade() * 10; //潜能
	score += item.getPdd() * 1; //防御
	if(item.getCHUC() == 25) {
		score += 2000;
	} else if(item.getCHUC() == 24) {
		score += 1000;
	} else if(item.getCHUC() == 23) {
		score += 700;
	} else if(item.getCHUC() == 22) {
		score += 500;
	} else if(item.getCHUC() >= 20) {
		score += 300;
	} else if(item.getCHUC() >= 15) {
		score += 200;
	} else if(item.getCHUC() >= 10) {
		score += 100;
	} else if(item.getCHUC() >= 5) {
		score += 50;
	}
	score += item.getArc() * 10;
	score += item.getArcLevel() * 10;
	score += Socket(item.getSocket(1));
	score += Socket(item.getSocket(2));
	score += Socket(item.getSocket(3));
	if(postion == -11) {
		//说明是武器 2万破功1评分,2000000001破功的，按20亿计算
		if(item.getLimitBreak() >= 300000000000) {
			score += parseInt(300000000000 / 1000000);
		} else {
			score += parseInt(item.getLimitBreak() / 1000000);
		}
	}
	return score;
} else {
	return 0;
}
}