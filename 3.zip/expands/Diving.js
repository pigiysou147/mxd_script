﻿npc.sayNextSNoEsc("哎呀，那只死猫害我，说好的没事的。");
player.changeMap(101070001);