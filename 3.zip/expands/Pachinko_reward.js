

player.openPachinko(true);