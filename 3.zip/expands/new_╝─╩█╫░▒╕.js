var itemlist = new Array(
	Array(1152196,1),//	神秘之影战士护肩
	Array(1152197,1),//	神秘之影法师护肩
	Array(1152198,1),//	神秘之影弓箭手护肩
	Array(1152199,1),//	神秘之影飞侠护肩
	Array(1152200,1),//	神秘之影海盗护肩
	Array(1004808,1),//	神秘之影战士帽
	Array(1004809,1),//	神秘之影法师帽
	Array(1004810,1),//	神秘之影弓箭手帽
	Array(1004811,1),//	神秘之影飞侠帽
	Array(1004812,1),//	神秘之影海盗帽
	Array(1102940,1),//	神秘之影战士披风
	Array(1102941,1),//	神秘之影法师披风
	Array(1102942,1),//	神秘之影弓箭手披风
	Array(1102943,1),//	神秘之影飞侠披风
	Array(1102944,1),//	神秘之影海盗披风
	Array(1082695,1),//	神秘之影战士手套
	Array(1082696,1),//	神秘之影法师手套
	Array(1082697,1),//	神秘之影弓箭手手套
	Array(1082698,1),//	神秘之影飞侠手套
	Array(1082699,1),//	神秘之影海盗手套
	Array(1053063,1),//	神秘之影战士套装
	Array(1053064,1),//	神秘之影法师套装
	Array(1053065,1),//	神秘之影弓箭手套装
	Array(1053066,1),//	神秘之影飞侠套装
	Array(1053067,1),//	神秘之影海盗套装
	Array(1073158,1),//	神秘之影战士鞋
	Array(1073159,1),//	神秘之影法师鞋
	Array(1073160,1),//	神秘之影弓箭手鞋
	Array(1073161,1),//	神秘之影飞侠鞋
	Array(1073162,1),//	神秘之影海盗鞋 防具尾巴 index 29
	Array(1212120,1),//	神秘之影双头杖
	Array(1222113,1),//	神秘之影灵魂手铳
	Array(1232113,1),//	神秘之影亡命剑
	Array(1242121,1),//	神秘之影能量剑
	Array(1242122,1),//	神秘之影能量剑
	Array(1252098,1),//	神秘之影魔法槌
	Array(1262039,1),//	神秘之影ESP限制器
	Array(1272017,1),//	神秘之影锁链
	Array(1282017,1),//	神秘之影魔力手套
	Array(1302343,1),//	神秘之影单手剑
	Array(1312203,1),//	神秘之影斧
	Array(1322255,1),//	神秘之影锤
	Array(1332279,1),//	神秘之影匕首
	Array(1342104,1),//	神秘之影刃
	Array(1362140,1),//	神秘之影手杖
	Array(1372228,1),//	神秘之影短杖
	Array(1382265,1),//	神秘之影长杖
	Array(1402259,1),//	神秘之影双手剑
	Array(1412181,1),//	神秘之影双手战斧
	Array(1422189,1),//	神秘之影双手锤
	Array(1432218,1),//	神秘之影长枪
	Array(1442274,1),//	神秘之影矛
	Array(1452257,1),//	神秘之影弓
	Array(1462243,1),//	神秘之影弩
	Array(1472265,1),//	神秘之影拳套
	Array(1482221,1),//	神秘之影指节
	Array(1492235,1),//	神秘之影短枪
	Array(1522143,1),//	神秘之影双弩枪
	Array(1532150,1),//	神秘之影攻城炮
	Array(1542117,1),//	神秘之影武士刀
	Array(1592037,1),//	神秘之影远古弓
	Array(1592020,1),//	神秘之影远古弓
	Array(1552119,1),//	 神秘之影折扇 
	Array(1582023,1),//	神秘之影机甲枪
	Array(1690204,1),//	神秘之影武器
	Array(1690321,1),//	神秘之影鞋子
	Array(1690322,1),//	神秘之影手套
	Array(1690323,1),//	神秘之影披风
	Array(1690324,1),//	神秘之影套服
	Array(1690325,1),//	神秘之影帽子
	Array(1690326,1),//	神秘之影肩饰
	Array(1672073,1),//妖精心脏
	Array(1022278,1),//蕴藏魔力的眼罩			
	Array(1012632,1),//失控机械标记			
	Array(1132308,1),//梦幻腰带			
	Array(1162080,1),//被诅咒的魔道书-红			
	Array(1162082,1),//被诅咒的魔道书-绿			
	Array(1162081,1),//被诅咒的魔道书-蓝			
	Array(1162083,1),//被诅咒的魔道书-黄		
	Array(1122430,1),//痛苦根源
	Array(1122296,1),//死神的项链	
	Array(1032316,1),//船长姿态耳环
	Array(1113306,1),//巨大恐惧
	Array(1672069,1),//女武神心脏
	
	Array(1190302,1),//水晶枫叶徽章
	Array(1182017,1),//黄金休彼德蔓徽章II
	Array(1202138,1),//猎人图腾
	Array(1202137,1),//兽王图腾
	Array(1202136,1),//熊掌图腾
	Array(1202193,1),//轮回碑石
	Array(1122267,1),//最高级贝勒德
	Array(1132246,1),//最高级贝勒德
	Array(1032223,1),//最高级贝勒德
	Array(1113075,1),//最高级贝勒德
	
	Array(1592033,1),//特米纳斯防御盾	
	Array(1092113,1),//特米纳斯防御盾			
	Array(1492191,1),//特米纳斯暴徒短枪			
	Array(1412148,1),//特米纳斯破坏大斧			
	Array(1462205,1),//特米纳斯疾风弩			
	Array(1212080,1),//特米纳斯启迪双头杖			
	Array(1422153,1),//特米纳斯爆破钝器			
	Array(1382223,1),//特米纳斯催眠长杖			
	Array(1232075,1),//特米纳斯亡命征服者			
	Array(1332239,1),//特米纳斯徘徊刀			
	Array(1272029,1),//特米纳斯极限锁链			
	Array(1432179,1),//特米纳斯尖刺枪			
	Array(1302290,1),//特米纳斯分裂剑			
	Array(1342086,1),//特米纳斯寂静刃			
	Array(1532110,1),//特米纳斯爆燃手炮			
	Array(1452217,1),//特米纳斯风暴弓			
	Array(1482180,1),//特米纳斯突击指节			
	Array(1552068,1),//特米纳斯召唤折扇			
	Array(1262030,1),//特米纳斯ESP限制器			
	Array(1442235,1),//特米纳斯战争矛			
	Array(1402211,1),//特米纳斯压制巨剑			
	Array(1242081,1),//特米纳斯狙击能量剑			
	Array(1222075,1),//特米纳斯烈焰魂手铳			
	Array(1582026,1),//特米纳斯爆裂铁拳			
	Array(1522106,1),//特米纳斯猛兽双弩枪			
	Array(1472227,1),//特米纳斯天罚拳套			
	Array(1252066,1),//特米纳斯动物魔法棒			
	Array(1312166,1),//特米纳斯撕裂斧			
	Array(1372189,1),//特米纳斯附魔短杖			
	Array(1322216,1),//特米纳斯粉碎锤			
	Array(1282029,1),//特米纳斯终点魔力手套			
	Array(1542068,1),//特米纳斯一文字刀			
	Array(1362102,1),//特米纳斯管弦乐手杖
	Array(1242134,1),//月夜见尊的天雷剑			
	Array(1362146,1),//月夜见尊的惨鬼杖			
	Array(1582037,1),//月夜见尊的龙甲手枪			
	Array(1472271,1),//月夜见尊的惨魔拳			
	Array(1332286,1),//月夜见尊的斩杀刀					
	Array(1252102,1),//天钿女命的灵魂棒			
	Array(1552126,1),//天钿女命的赤花蝶扇			
	Array(1382271,1),//天钿女命的魔灵杖			
	Array(1262046,1),//天钿女命的ESP限制器			
	Array(1212126,1),//天钿女命的眩光杖			
	Array(1372234,1),//天钿女命的却鬼棒			
	Array(1282030,1),//天命魔力手套			
	Array(1272030,1),//月神锁链			
	Array(1442282,1),//天照的天羽羽斩			
	Array(1312209,1),//天照的天月斧			
	Array(1422194,1),//天照的破雳刚杵			
	Array(1542124,1),//天照的村正			
	Array(1412186,1),//天照的鬼炎斧			
	Array(1402265,1),//天照的御魂剑			
	Array(1322261,1),//天照的金刚杵			
	Array(1232119,1),//天照的猛岚剑			
	Array(1432224,1),//天照的风灭戟			
	Array(1302349,1),//天照的丛云剑			
	Array(1492241,1),//素盏呜尊的雷激枪			
	Array(1482229,1),//素盏呜尊的惨血熊千			
	Array(1532154,1),//素盏呜尊的红炎炮			
	Array(1242135,1),//素盏呜尊的豪雷剑			
	Array(1222119,1),//素盏呜尊的虹击炮			
	Array(1462249,1),//大山祇神的大通莲弓			
	Array(1452263,1),//大山祇神的火魂弓			
	Array(1522149,1),//大山祇神的双龙闪弩
	Array(1004075,1),//海神王冠
	Array(1082489,1),//高级次元手套
	Array(1102887,1),//缘分之翼
	Array(1032219,1),//遗忘之神话耳环			
	Array(1190900,1),//永恒时间徽章						
	Array(1182136,1),//MX-131徽章			
	Array(1182158,1),//奥尔卡的徽章
	Array(1182006,1),//传说勇士徽章			
	Array(1182011,1),//正义英雄徽章
	Array(1182087,1),//水晶幸运徽章	
	Array(1202261,1),//玉壶图腾			
	Array(1202262,1),//青铜香炉图腾			
	Array(1202260,1),//骑马像图腾			
	Array(1202161,1),//水精灵图腾			
	Array(1202162,1),//吐精灵图腾			
	Array(1202163,1),//风精灵图腾			
	Array(1202164,1),//风精灵图腾					
	Array(1202090,1),//真·本多忠胜图腾			
	Array(1202089,1),//真·真田幸村图腾			
	Array(1202091,1),//真·上杉谦信图腾						
	Array(1202087,1),//黑蛇图腾			
	Array(1202088,1),//白蛇图腾				
	Array(1202119,1),//异界的希纳斯图腾			
	Array(1202189,1),//护理员的图腾			
	Array(1202188,1),//护士的图腾			
	Array(1202187,1),//医院院长的图腾
	Array(1592036,1),//极限古功
	// Array(1022211,1),//漩涡眼镜			
	// Array(1102623,1),//漩涡披风			
	// Array(1082556,1),//漩涡手套			
	// Array(1052669,1),//漩涡皇家外套						
	// Array(1072870,1),//漩涡鞋			
	// Array(1152160,1),//漩涡护肩			
	// Array(1272028,1),//漩涡锁链			
	// Array(1032224,1),//漩涡耳环			
	// Array(1132247,1),//漩涡腰带
	// Array(1012438,1),//漩涡文身			
	// Array(1122269,1),//漩涡吊坠			
	// Array(1003976,1),//漩涡帽子	
	// Array(1422158,1),//漩涡巨锤			
	// Array(1482189,1),//漩涡冲拳			
	// Array(1552072,1),//漩涡之风			
	// Array(1302297,1),//漩涡剑			
	// Array(1242090,1),//漩涡锁链剑			
	// Array(1462213,1),//漩涡弩			
	// Array(1212089,1),//漩涡双头杖			
	// Array(1362109,1),//漩涡手杖						
	// Array(1232084,1),//漩涡恶魔剑			
	// Array(1582025,1),//漩涡拳炮			
	// Array(1322223,1),//漩涡锤					
	// Array(1522113,1),//漩涡双翼弩			
	// Array(1452226,1),//漩涡弓			
	// Array(1472235,1),//漩涡拳甲			
	// Array(1332247,1),//漩涡匕首			
	// Array(1222084,1),//漩涡灵魂手铳			
	// Array(1382231,1),//漩涡长杖			
	// Array(1532118,1),//漩涡手炮			
	// Array(1252033,1),//漩涡虎梳魔法棒			
	// Array(1402220,1),//漩涡双手剑			
	// Array(1312173,1),//漩涡斧			
	// Array(1262029,1),//漩涡ESP限制器
	// Array(1282028,1),//漩涡魔力手套			
	// Array(1492199,1),//漩涡手铳			
	// Array(1372195,1),//漩涡短杖			
	// Array(1412152,1),//漩涡双手战斧			
	// Array(1542072,1),//漩涡武士之剑			
	// Array(1432187,1),//漩涡矛						
	// Array(1442242,1),//漩涡戟	
	// Array(1592032,1),//漩涡古弓	
	// Array(1342090,1),//漩涡刀
	Array(1342109,1),//新战国刀
	Array(1092088,1),//战神飞侠盾
	Array(1092089,1),//战神法师盾
	Array(1092087,1),//战神战士盾
	Array(1092111,1),//外星人飞侠盾
	Array(1092110,1),//外星人法师盾
	Array(1092109,1),//外星人战士盾
	Array(1672073,1),//妖精心脏
	Array(1113070,1),//真红戒指
	Array(1152155,1),//真红护肩
	Array(1032216,1),//真红耳环
	Array(1102482,1),//暴君赫尔梅斯披风		
	Array(1102485,1),//暴君阿尔泰披风			
	Array(1102481,1),//暴君西亚戴斯披风			
	Array(1102484,1),//暴君利卡昂披风
	Array(1102483,1),//暴君凯伦披风								
	Array(1082545,1),//暴君凯伦手套			
	Array(1082547,1),//暴君阿尔泰手套			
	Array(1082546,1),//暴君利卡昂手套			
	Array(1082543,1),//暴君西亚戴斯手套			
	Array(1082544,1),//暴君赫尔梅斯手套			
	Array(1072747,1),//暴君阿尔泰靴			
	Array(1072746,1),//暴君利卡昂靴			
	Array(1072743,1),//暴君西亚戴斯靴			
	Array(1072745,1),//暴君凯伦靴			
	Array(1072744,1),//暴君赫尔梅斯靴			
	Array(1132178,1),//暴君阿尔泰腰带			
	Array(1132174,1),//暴君西亚戴斯腰带			
	Array(1132175,1),//暴君赫尔梅斯腰带			
	Array(1132176,1),//暴君凯伦腰带			
	Array(1132177,1),//暴君利卡昂腰带
	Array(1004424,1),//埃苏莱布斯弓箭手帽			
	Array(1052882,1),//埃苏莱布斯骑士套装			
	Array(1004422,1),//埃苏莱布斯骑士头盔			
	Array(1052887,1),//埃苏莱布斯魔法师套装			
	Array(1004425,1),//埃苏莱布斯飞侠帽			
	Array(1052888,1),//埃苏莱布斯弓箭手套装			
	Array(1004423,1),//埃苏莱布斯法师帽			
	Array(1004426,1),//埃苏莱布斯海盗帽			
	Array(1052890,1),//埃苏莱布斯海盗套装			
	Array(1052889,1),//埃苏莱布斯飞侠套装			
	Array(1073032,1),//埃苏莱布斯法师鞋				
	Array(1073030,1),//埃苏莱布斯骑士鞋			
	Array(1102795,1),//埃苏莱布斯弓箭手披风		
	Array(1102794,1),//埃苏莱布斯魔法师披风			
	Array(1102775,1),//埃苏莱布斯骑士披风			
	Array(1073035,1),//埃苏莱布斯海盗鞋			
	Array(1073034,1),//埃苏莱布斯飞侠鞋			
	Array(1102797,1),//埃苏莱布斯海盗披风			
	Array(1102796,1),//埃苏莱布斯飞侠披风			
	Array(1073033,1),//埃苏莱布斯弓箭手鞋			
	Array(1152177,1),//埃苏莱布斯弓箭手护肩	
	Array(1152176,1),//埃苏莱布斯法师护肩			
	Array(1152174,1),//埃苏莱布斯骑士护肩			
	Array(1152178,1),//埃苏莱布斯飞侠护肩			
	Array(1152179,1),//埃苏莱布斯海盗护肩			
	Array(1592019,1),//真挨苏武器			
	Array(1542108,1),//真挨苏武器			
	Array(1252093,1),//真挨苏武器			
	Array(1552110,1),//真挨苏武器			
	Array(1582017,1),//真挨苏武器			
	Array(1532144,1),//真挨苏武器			
	Array(1522138,1),//真挨苏武器			
	Array(1492231,1),//真挨苏武器			
	Array(1482216,1),//真挨苏武器			
	Array(1472261,1),//真挨苏武器			
	Array(1372222,1),//真挨苏武器			
	Array(1362135,1),//真挨苏武器			
	Array(1342101,1),//真挨苏武器			
	Array(1412177,1),//真挨苏武器			
	Array(1402251,1),//真挨苏武器			
	Array(1382259,1),//真挨苏武器			
	Array(1332274,1),//真挨苏武器			
	Array(1322250,1),//真挨苏武器			
	Array(1312199,1),//真挨苏武器			
	Array(1302333,1),//真挨苏武器			
	Array(1282016,1),//真挨苏武器			
	Array(1272016,1),//真挨苏武器			
	Array(1262017,1),//真挨苏武器			
	Array(1242120,1),//真挨苏武器			
	Array(1242116,1),//真挨苏武器			
	Array(1232109,1),//真挨苏武器			
	Array(1222109,1),//真挨苏武器			
	Array(1212115,1),//真挨苏武器
	Array(1442223,1),//法弗纳半月宽刃斧						
	Array(1492179,1),//法弗纳左轮枪			
	Array(1242060,1),//法弗纳精神之刃									
	Array(1422140,1),//法弗纳闪电锤					
	Array(1242061,1),//法弗纳精神之刃						
	Array(1412135,1),//法弗纳战斗切肉斧						
	Array(1532098,1),//法弗纳荣耀炮						
	Array(1332225,1),//法弗纳大马士革剑						
	Array(1432167,1),//法弗纳贯雷枪			
	Array(1462193,1),//法弗纳风翼弩								
	Array(1272015,1),//法弗纳锁链						
	Array(1282015,1),//法弗纳魔力手套								
	Array(1482168,1),//法弗纳巨狼之爪					
	Array(1382208,1),//法弗纳魔冠之杖						
	Array(1322203,1),//法弗纳戈耳迪锤			
	Array(1472214,1),//法弗纳危险之手			
	Array(1262016,1),//法弗纳ESP限制器									
	Array(1232057,1),//法弗纳死亡使者			
	Array(1342082,1),//法弗纳急速之刃
	Array(1372177,1),//法弗纳魔力夺取者			
	Array(1312153,1),//法弗纳双刃切肉斧					
	Array(1522094,1),//法弗纳双风翼弩						
	Array(1222058,1),//法弗纳天使手铳						
	Array(1542063,1),//法弗纳皇刀正宗				
	Array(1362090,1),//法弗纳洞察手杖					
	Array(1302275,1),//法弗纳银槲之剑			
	Array(1582016,1),//法弗纳巨山						
	Array(1212063,1),//法弗纳魔力源泉杖				
	Array(1252015,1),//法弗纳北极星魔法棒					
	Array(1452205,1),//法弗纳追风者			
	Array(1402196,1),//法弗纳忏悔之剑			
	Array(1552063,1),//法弗纳煌扇蓝姬	
	Array(1403036,1),//法弗纳煌扇蓝姬
	Array(1592018,1),//法弗纳远古弓
	Array(1382235,1),//阿丽莎
	Array(1402224,1),//柳德
	Array(1402180,1),//解放的凯瑟利安
	Array(1352906,1),//银河之腕轮	
	Array(1352266,1),//银河之风暴羽毛			
	Array(1352815,1),//银河之私语
	Array(1352975,1),//银河之圣地之光			
	Array(1353006,1),//银河之控制器			
	Array(1352506,1),//银河之精髓			
	Array(1352406,1),//银河之魂珠			
	Array(1352606,1),//银河之灵魂手镯			
	Array(1352236,1),//银河之赤铜之书			
	Array(1352276,1),//银河之扳指			
	Array(1353606,1),//精气球			
	Array(1353505,1),//浓姬的发射器			
	Array(1353306,1),//浓姬的不灭之翼			
	Array(1352824,1),//宿命之拳			
	Array(1353205,1),//棋子王			
	Array(1552084,1),//妖蝶姬之花扇			
	Array(1352807,1),//妖蝶姫之小太刀			
	Array(1352957,1),//银河之极限球			
	Array(1353405,1),//银河之爆破弹			
	Array(1352216,1),//银河之念珠			
	Array(1352916,1),//银河之鹰眼			
	Array(1352226,1),//银河之锁链			
	Array(1352246,1),//银河之青银之书			
	Array(1352928,1),//银河之火药桶			
	Array(1352296,1),//银河之灵符						
	Array(1352286,1),//银河之剑鞘			
	Array(1352945,1),//银河之龙神的遗产			
	Array(1099012,1),//银河之盾			
	Array(1352935,1),//银河之天龙锤			
	Array(1352707,1),//银河之麦林弹			
	Array(1352009,1),//银河之箭矢			
	Array(1352206,1),//银河之吊坠			
	Array(1352256,1),//银河之白金之书			
	Array(1352967,1),//银河之狂野之矛			
	Array(1352109,1),//银河之卡片			
	Array(1353105,1),//银河之狐狸珠			
	Array(1099011,1),//银河之咒盾	
	Array(1353707,1),//不滅的遺跡
	Array(1113211,1)//天堂气息
	
	
);
var text = "请选择你要寄售的物品#r(刚砸的道具一定要小退,确保装备保存在数据库中,因为有缓存.请切记上架前小退.)#k\r\n";

var index=0;
for(var i = 1;i<129;i++){
	var item = player.getInventorySlot(1,i);
	if(item == null){
		continue;
	}else if(item.getData().isCash()){
		continue;
	}else{
		var flag = false;
		
		for(var j = 0;j<itemlist.length;j++){
			if(itemlist[j][0]==item.getItemId()){
				flag = true;
				index=j;
				break;
			}
		}
		if(!flag){
			continue;
		}else{
			text += "#L"+i+"# #v"+item.getItemId()+"##t"+item.getItemId()+"# 位置："+i+"#l\r\n";	
		}
	}
}
var pos = npc.askMenu(text);
var text = "您将上架物品信息\r\n";
var item = player.getInventorySlot(1,pos);
	text+= "#v"+item.getItemId()+"\r\n";
	text +="力量："+item.getStr()+"\r\n";
	text +="敏捷："+item.getDex()+"\r\n";
	text +="智力："+item.getInt()+"\r\n";
	text +="运气："+item.getLuk()+"\r\n";
	text +="物理攻击："+item.getPad()+"\r\n";
	text +="魔法攻击："+item.getMad()+"\r\n";
	text +="防御："+item.getPdd()+"\r\n";
var meso = npc.askNumber(text+"请输入您要寄售的现金价格",100,20,5000);
var limit =0;
var itemid=item.getItemId();
for(var j = 0;j<itemlist.length;j++){
	if(itemlist[j][0]==item.getItemId()){
		index=j;
		break;
	}
}
if(index<=29){
	limit=150;
}else if(index>=29 && index<=70){
	limit=100;
}
var yes = npc.askYesNo("您确定要上架#v"+item.getItemId()+"# 价格："+meso+"吗?");

if(yes == 1){
	if( item.getCuttable()==0){
		//没有交易次数了
		npc.say("该件装备的交易次数为:"+item.getCuttable()+"无法进行上架");
	}else{
		//进行价格限制
		//神秘防具100
		
		//神秘武器200
		if(limit>meso){
			npc.say("你的装备#v"+itemid+"# 最低售价为:"+limit);
		}else{
			//将道具信息插入寄售里
			var entid = getEntId(item);
			if(hasEquip(entid) ==item.getItemId()){
				var iid = getKeyId();
				
				//记录总流水
				addJsLog(entid,meso,iid);
				copyEquip(item,entid,iid);//记录流水
				addSale(entid,item.getItemId(),meso,iid);//记录装备表和谁寄售的
				player.loseInvSlot(1, pos);
				npc.broadcastGachaponMsgEx("[交易所装备上架] :道具名字："+item.getItemName()+"  售价"+meso+"直充点 各位玩家请关注",item);
				npc.say("上架成功.");
			}else{
				npc.say("数据库中找不到这件道具,请重新登陆后再尝试。"+entid);
			}
		}
		
	}
}

function addSale(entid,itemid,meso,iid){
	var sql = " insert into zz_js_sale(characters_id,type,sn,itemid,number,paytime,meso,iid)VALUES(?,1,?,?,1,now(),?,?) ";
	
	player.customSqlInsert(sql,player.getId(),entid,itemid,meso,iid);
}
function copyEquip(item,entid,iid){
	//var sql = " INSERT INTO zz_js_inventoryitems_equip values(";
	// sql+=entid+",";
	// sql+=item.getSN()+",";
	// sql+=item.getItemId()+",";
	// sql+=item.getDateExpire()+",";
	// sql+="'"+item.getTitle()+"',";
	// sql+=item.getFtEquipped()+",";
	// sql+=item.getPrevBonusExpRate()+",";
	// sql+=item.getRUC()+",";
	// sql+=item.getCUC()+",";
	// sql+=item.getStr()+",";
	// sql+=item.getDex()+","; 
	// sql+=item.getInt()+","; 
	// sql+=item.getLuk()+","; 
	// sql+=item.getMaxHp()+","; 
	// sql+=item.getMaxMp()+","; 
	// sql+=item.getPad()+",";
	// sql+=item.getMad()+",";
	// sql+=item.getPdd()+",";
	// sql+=item.getCraft()+",";
	// sql+=item.getSpeed()+",";
	// sql+=item.getJump()+",";
	// sql+=item.getAttribute()+",";
	// sql+=item.getLevelUpType()+",";
	// sql+=item.getIncSkill()+",";	
	// sql+=item.getLevel()+",";
	// sql+=item.getExp()+",";
	// sql+=item.getDurability()+",";
	// sql+=item.getIUC()+",";
	// sql+=item.getPVPDamage()+",";
	// sql+=item.getReduceReq()+",";	
	// sql+=item.getSpecialAttribute()+",";
	// sql+=item.getDurabilityMax()+",";
	// sql+=item.getIncReq()+",";	
	// sql+=item.getGrowthEnchant()+",";
	// sql+=0+",";
	// sql+=item.getBossDamageR()+",";
	// sql+=item.getIgnorePDR()+",";	
	// sql+=item.getDamR()+",";
	// sql+=item.getStatR()+",";	
	// sql+=item.getCuttable()+",";
	// sql+=item.getExGradeOption()+",";
	// sql+=item.getItemState()+",";
	// sql+=item.getFtExpireDate()+",";
	// sql+=item.getCSGrade()+",";
	// sql+="0,";
	// sql+="0,";
	// sql+="0,";
	// sql+=item.getGrade()+",";
	// sql+=item.getCHUC()+",";
	// sql+=item.getOption(1,false)+",";
	// sql+=item.getOption(2,false)+",";
	// sql+=item.getOption(3,false)+",";
	// sql+=item.getOption(1,true)+",";
	// sql+=item.getOption(2,true)+",";
	// sql+=item.getOption(3,true)+",";
	// sql+=item.getItemSkin()+",";
	// sql+=item.getSocket(1)+",";
	// sql+=item.getSocket(2)+",";
	// sql+=item.getSocket(3)+",";
	// sql+=item.getMixColor()+",";
	// sql+=item.getSoulOption()+",";
	// sql+=item.getSoulSocketID()+",";
	// sql+=item.getSoulOptionID()+",";
	// sql+=item.getArc()+",";
	// sql+=item.getArcExp()+",";
	// sql+=item.getArcLevel()+",";
	// sql+=item.getLimitBreak()+",";
	// sql+=iid+")";
	var sql ="INSERT into zz_js_inventoryitems_equip SELECT * from inventory_equip where id = "+item.getOnlyId();
	
	player.customSqlInsert(sql);
}

function addJsLog(entid,meso,iid){
	var sql = " INSERT INTO zz_js_log values( "+iid+","+player.getId()+","+meso+",NULL,0,'正在出售',";
	sql+=entid+")";
	// sql+=item.getOnlyId()+",";
	// sql+=item.getItemId()+",";
	// sql+=item.getDateExpire()+",";
	// sql+="'"+item.getTitle()+"',";
	// sql+=1+",";
	// sql+=-1+",";
	// sql+=item.getRUC()+",";
	// sql+=item.getCUC()+",";
	// sql+=item.getStr()+",";
	// sql+=item.getDex()+","; 
	// sql+=item.getInt()+","; 
	// sql+=item.getLuk()+","; 
	// sql+=item.getMaxHp()+","; 
	// sql+=item.getMaxMp()+","; 
	// sql+=item.getPad()+",";
	// sql+=item.getMad()+",";
	// sql+=item.getPdd()+",";
	// sql+=item.getCraft()+",";
	// sql+=item.getSpeed()+",";
	// sql+=item.getJump()+",";
	// sql+=item.getAttribute()+",";
	// sql+=0+",";
	// sql+=item.getIncSkill()+",";	
	// sql+=item.getLevel()+",";
	// sql+=item.getExp()+",";
	// sql+=item.getDurability()+",";
	// sql+=item.getIUC()+",";
	// sql+=item.getPVPDamage()+",";
	// sql+=item.getReduceReq()+",";	
	// sql+=item.getSpecialAttribute()+",";
	// sql+=item.getDurabilityMax()+",";
	// sql+=item.getIncReq()+",";	
	// sql+=item.getGrowthEnchant()+",";
	// sql+=0+",";
	
	// sql+=item.getBossDamageR()+",";
	// sql+=item.getIgnorePDR()+",";	
	// sql+=item.getDamR()+",";
	// sql+=item.getStatR()+",";	
	// sql+=item.getCuttable()+",";
	// sql+=item.getExGradeOption()+",";
	// sql+=item.getItemState()+",";
	// sql+=item.getFtExpireDate()+",";
	// sql+=item.getCSGrade()+",";
	// sql+="0,";
	// sql+="0,";
	// sql+="0,";
	// sql+=item.getGrade()+",";
	// sql+=item.getCHUC()+",";
	// sql+=item.getOption(1,false)+",";
	// sql+=item.getOption(2,false)+",";
	// sql+=item.getOption(3,false)+",";
	// sql+=item.getOption(1,true)+",";
	// sql+=item.getOption(2,true)+",";
	// sql+=item.getOption(3,true)+",";
	// sql+=item.getItemSkin()+",";
	// sql+=item.getSocket(1)+",";
	// sql+=item.getSocket(2)+",";
	// sql+=item.getSocket(3)+",";
	// sql+=item.getMixColor()+",";
	// sql+=item.getSoulOption()+",";
	// sql+=item.getSoulSocketID()+",";
	// sql+=item.getSoulOptionID()+",";
	// sql+=item.getArc()+",";
	// sql+=item.getArcExp()+",";
	// sql+=item.getArcLevel()+",";
	// sql+=item.getLimitBreak()+"";
	// sql+=")";
	
	player.customSqlInsert(sql);
}

 
function getKeyId(){
	var sql = " SELECT iid FROM zz_js_iid order by iid desc LIMIT 1 ";
	var resultList = player.customSqlResult(sql);
	
	player.customSqlUpdate("update zz_js_iid set iid = iid+1");
	
	if(resultList.size()==0){
		return 1;
	}else{
		return parseInt(resultList.get(0).get("iid"))+1;
	}
}



function hasEquip(entid){
	var sql = "SELECT itemid from inventory_equip  where id = ? ";
	var resultList = player.customSqlResult(sql,entid);
	var itemid = -1;
	for (var i = 0; i < resultList.size(); i++) {
		var result = resultList.get(i);
		if (result == null) {
			break;
		}
		itemid = result.get("itemid");
	}
	return itemid;
}

function getEntId(item){
	return item.getOnlyId();
}

function isCashItem(itemid){
	return player.makeItemWithId(itemid).getOnlyId()>-1;
}
